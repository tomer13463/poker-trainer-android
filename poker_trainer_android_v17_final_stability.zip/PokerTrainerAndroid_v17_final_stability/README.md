PokerTrainerAndroid v11 Device QA

Fixes vs v10:
- Fixed Kotlin multiline string compilation issue in FloatingOverlayService.
- Added device QA notes for permissions, overlay, and screen-size testing.

Manual device QA flow:
1. Install app-debug.apk.
2. Open app and test manual overlay first.
3. Approve Display over other apps.
4. Open floating window and choose cards manually. Verify win/strength/future bars update.
5. Open auto mode and approve screen capture.
6. Test YouTube portrait, YouTube fullscreen, TikTok portrait.
7. Use screen profile button: Auto / Green table / PokerFace red.
8. If detection is wrong, tap Save debug frame and send screenshot/frame.

Known limitations:
- Automatic card detection is MVP template/color/region based.
- It is tuned only for the two example table layouts sent in chat.
- Exact TikTok/YouTube accuracy depends on video scale, crop, and card design.


## v12 Deep QA fixes
- Safer MediaProjection intent extraction for Android 13+.
- Prevents bitmap memory leaks if card detection throws an exception.
- Safe cleanup of ImageReader, VirtualDisplay, and MediaProjection.
- Overlay move/update actions wrapped to avoid crash if view is detached.
- Screen-capture action calls wrapped so background-service restrictions show an error instead of crashing.
- Analyzer execution wrapped so invalid card states do not crash the overlay.
- Notification permission is requested only when not already granted.

## v13 - הודעות שגיאה ולוגים
נוסף מנגנון ErrorReporter:
- אם יש קריסה כללית, נשמרת שגיאה אחרונה ב־SharedPreferences ובקובץ logs/last_error.txt.
- אם יש בעיה בהרשאות, חלון צף, צילום מסך, זיהוי קלפים או חישוב אחוזים — מוצגת הודעה בעברית באפליקציה/חלון הצף.
- במסך הראשי נוספו כפתורים: "הצג שגיאה אחרונה" ו־"נקה שגיאות".
- אם הזיהוי/החישוב נופלים, החלון לא אמור להיסגר מיד; הוא מציג איפה הבעיה.


## v16 - כיול עם הגדלה/הקטנה
נוסף מצב כיול מיקומים משופר:
- גרירת מסגרת "היד שלי"
- גרירת מסגרת "קלפי שולחן"
- כפתורי + / - בתוך כל מסגרת להגדלה והקטנה
- המסגרות לא יוצאות מחוץ למסך
- שמירה לפרופיל "מותאם"


## v17 - בדיקות יציבות אחרונות
- זיהוי פריימים עבר ל-HandlerThread ייעודי כדי לא לתקוע את ה-Main Thread.
- נוספה הגנה מפני עיבוד כפול של פריימים במקביל.
- ניקוי בטוח יותר של CaptureThread בסגירת השירות.
- בדיקת הרשאות/Manifest/Theme/Gradle נבדקו סטטית.
- נשמרו כל השיפורים של v16: כיול ידני, גרירה, הגדלה/הקטנה, פרופיל מותאם.
