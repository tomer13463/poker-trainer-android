package com.tomer.pokertrainer.overlay

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.tomer.pokertrainer.capture.ScreenCaptureService
import com.tomer.pokertrainer.util.CalibrationStore
import com.tomer.pokertrainer.util.ErrorReporter
import com.tomer.pokertrainer.util.RectRel

class CalibrationOverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var root: FrameLayout
    private lateinit var heroBox: LinearLayout
    private lateinit var boardBox: LinearLayout
    private lateinit var heroParams: WindowManager.LayoutParams
    private lateinit var boardParams: WindowManager.LayoutParams
    private lateinit var rootParams: WindowManager.LayoutParams

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val metrics = resources.displayMetrics
        val sw = metrics.widthPixels
        val sh = metrics.heightPixels

        rootParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0; y = 0
        }

        root = FrameLayout(this).apply {
            setBackgroundColor(0x22000000)
        }

        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(0xF21F2937.toInt(), 18f, 0xFF4B5563.toInt())
        }
        val info = TextView(this).apply {
            text = "מצב כיול: גרור מסגרות, ולחץ + / - כדי להגדיל או להקטין"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }
        val saveBtn = smallButton("שמור") { saveCalibration(sw, sh) }
        val cancelBtn = smallButton("בטל") { stopSelf() }
        topBar.addView(info, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        topBar.addView(saveBtn)
        topBar.addView(cancelBtn)
        root.addView(topBar, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.TOP
            leftMargin = dp(10); rightMargin = dp(10); topMargin = dp(28)
        })

        heroBox = labeledBox("היד שלי", 0x6634D399, 0xFF34D399.toInt())
        boardBox = labeledBox("קלפי שולחן", 0x66F59E0B, 0xFFF59E0B.toInt())
        addResizeControls(heroBox)
        addResizeControls(boardBox)

        val heroSaved = CalibrationStore.hero(this)
        val boardSaved = CalibrationStore.board(this)
        heroParams = boxParams(
            width = (sw * ((heroSaved?.r ?: 0.78f) - (heroSaved?.l ?: 0.55f))).toInt().coerceAtLeast(dp(130)),
            height = (sh * ((heroSaved?.b ?: 0.94f) - (heroSaved?.t ?: 0.80f))).toInt().coerceAtLeast(dp(72)),
            x = (sw * (heroSaved?.l ?: 0.55f)).toInt(),
            y = (sh * (heroSaved?.t ?: 0.80f)).toInt()
        )
        boardParams = boxParams(
            width = (sw * ((boardSaved?.r ?: 0.82f) - (boardSaved?.l ?: 0.18f))).toInt().coerceAtLeast(dp(210)),
            height = (sh * ((boardSaved?.b ?: 0.52f) - (boardSaved?.t ?: 0.38f))).toInt().coerceAtLeast(dp(72)),
            x = (sw * (boardSaved?.l ?: 0.18f)).toInt(),
            y = (sh * (boardSaved?.t ?: 0.38f)).toInt()
        )

        root.addView(heroBox)
        root.addView(boardBox)
        heroBox.post {
            heroBox.x = heroParams.x.toFloat(); heroBox.y = heroParams.y.toFloat()
            heroBox.layoutParams = FrameLayout.LayoutParams(heroParams.width, heroParams.height)
        }
        boardBox.post {
            boardBox.x = boardParams.x.toFloat(); boardBox.y = boardParams.y.toFloat()
            boardBox.layoutParams = FrameLayout.LayoutParams(boardParams.width, boardParams.height)
        }

        installDrag(heroBox)
        installDrag(boardBox)

        runCatching { wm.addView(root, rootParams) }
            .onFailure { ErrorReporter.report(this, "כיול מסך", it, "לא הצלחתי להציג מסך כיול") }
    }

    private fun labeledBox(title: String, fill: Int, stroke: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(fill, 18f, stroke)
        setPadding(dp(10), dp(8), dp(10), dp(8))
        addView(TextView(this@CalibrationOverlayService).apply {
            text = title
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        })
        addView(TextView(this@CalibrationOverlayService).apply {
            text = "גרור לאזור הנכון • + / - משנה גודל"
            textSize = 11f
            setTextColor(0xFFE5E7EB.toInt())
        })
    }

    private fun boxParams(width: Int, height: Int, x: Int, y: Int): WindowManager.LayoutParams = WindowManager.LayoutParams(
        width, height,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y }

    private fun installDrag(box: View) {
        var startX = 0f
        var startY = 0f
        var downX = 0f
        var downY = 0f
        box.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = v.x
                    startY = v.y
                    downX = e.rawX
                    downY = e.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val metrics = resources.displayMetrics
                    v.x = (startX + e.rawX - downX).coerceIn(0f, (metrics.widthPixels - v.width).coerceAtLeast(0).toFloat())
                    v.y = (startY + e.rawY - downY).coerceIn(dp(70).toFloat(), (metrics.heightPixels - v.height).coerceAtLeast(dp(70)).toFloat())
                    true
                }
                else -> false
            }
        }
    }


    private fun addResizeControls(box: LinearLayout) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, 0)
        }
        val smaller = smallButton("−") { resizeBox(box, 0.92f) }
        val bigger = smallButton("+") { resizeBox(box, 1.08f) }
        row.addView(smaller, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(4) })
        row.addView(bigger, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(4) })
        box.addView(row)
    }

    private fun resizeBox(box: View, factor: Float) {
        val lp = box.layoutParams as? FrameLayout.LayoutParams ?: return
        val metrics = resources.displayMetrics
        val maxW = (metrics.widthPixels * 0.95f).toInt()
        val maxH = (metrics.heightPixels * 0.40f).toInt()
        val minW = dp(95)
        val minH = dp(58)

        lp.width = (lp.width * factor).toInt().coerceIn(minW, maxW)
        lp.height = (lp.height * factor).toInt().coerceIn(minH, maxH)
        box.layoutParams = lp

        // לא לתת למסגרת לברוח מחוץ למסך אחרי שינוי גודל.
        box.x = box.x.coerceIn(0f, (metrics.widthPixels - lp.width).coerceAtLeast(0).toFloat())
        box.y = box.y.coerceIn(dp(70).toFloat(), (metrics.heightPixels - lp.height).coerceAtLeast(dp(70)).toFloat())
    }

    private fun saveCalibration(sw: Int, sh: Int) {
        fun rectFor(v: View): RectRel {
            val l = (v.x / sw).coerceIn(0f, 1f)
            val t = (v.y / sh).coerceIn(0f, 1f)
            val r = ((v.x + v.width) / sw).coerceIn(0f, 1f)
            val b = ((v.y + v.height) / sh).coerceIn(0f, 1f)
            return RectRel(l, t, r, b).sanitize()
        }
        val hero = rectFor(heroBox)
        val board = rectFor(boardBox)
        CalibrationStore.save(this, hero, board)
        runCatching {
            startService(Intent(this, ScreenCaptureService::class.java).apply {
                action = ScreenCaptureService.ACTION_SET_PROFILE
                putExtra(ScreenCaptureService.EXTRA_PROFILE, "custom")
            })
        }
        Toast.makeText(this, "כיול נשמר. אפשר לעבור לפרופיל מותאם אישית.", Toast.LENGTH_LONG).show()
        stopSelf()
    }

    private fun smallButton(textValue: String, action: () -> Unit): Button = Button(this).apply {
        text = textValue
        textSize = 12f
        setTextColor(Color.WHITE)
        background = rounded(0xFF111827.toInt(), 14f, 0xFF6B7280.toInt())
        setOnClickListener { action() }
    }

    private fun rounded(color: Int, radius: Float, stroke: Int): GradientDrawable = GradientDrawable().apply {
        cornerRadius = radius
        setColor(color)
        setStroke(dp(2), stroke)
    }

    override fun onDestroy() {
        if (::root.isInitialized) runCatching { wm.removeView(root) }
        super.onDestroy()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
