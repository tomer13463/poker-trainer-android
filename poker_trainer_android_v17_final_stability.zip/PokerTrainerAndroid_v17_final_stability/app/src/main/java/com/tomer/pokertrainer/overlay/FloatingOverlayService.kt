package com.tomer.pokertrainer.overlay

import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Button
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.tomer.pokertrainer.util.CalibrationStore
import com.tomer.pokertrainer.capture.ScreenCaptureService
import com.tomer.pokertrainer.model.Card
import com.tomer.pokertrainer.model.Rank
import com.tomer.pokertrainer.model.Suit
import com.tomer.pokertrainer.poker.PokerAnalyzer
import com.tomer.pokertrainer.util.ErrorReporter
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

class FloatingOverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var resultText: TextView
    private lateinit var compactText: TextView
    private lateinit var winTitle: TextView
    private lateinit var winBar: ProgressBar
    private lateinit var strengthTitle: TextView
    private lateinit var strengthBar: ProgressBar
    private lateinit var futureTitle: TextView
    private lateinit var nextBar: ProgressBar
    private lateinit var riverBar: ProgressBar
    private lateinit var autoText: TextView
    private lateinit var lockBtn: Button
    private lateinit var profileBtn: Button
    private lateinit var compactBtn: Button
    private lateinit var detailsContainer: LinearLayout
    private lateinit var controlsContainer: LinearLayout

    private val analyzer = PokerAnalyzer()
    private val hero = mutableListOf<Card>()
    private val board = mutableListOf<Card>()
    private var opponents = 2
    private var heroLocked = false
    private var compactMode = false
    private var profileMode = "auto"
    private var startX = 0
    private var startY = 0
    private var touchX = 0f
    private var touchY = 0f
    private val analyzerExecutor = Executors.newSingleThreadExecutor()
    private val uiHandler = Handler(Looper.getMainLooper())
    private val analysisSeq = AtomicInteger(0)

    private val detectionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == ErrorReporter.ACTION_ERROR) {
                val area = intent.getStringExtra(ErrorReporter.EXTRA_AREA).orEmpty()
                val msg = intent.getStringExtra(ErrorReporter.EXTRA_MESSAGE).orEmpty()
                if (::autoText.isInitialized) autoText.text = "בעיה: $area\n$msg"
                return
            }
            if (intent?.action == ScreenCaptureService.ACTION_STATUS) {
                autoText.text = "אוטומטי: ${intent.getStringExtra(ScreenCaptureService.EXTRA_STATUS).orEmpty()}"
                return
            }
            if (intent?.action != ScreenCaptureService.ACTION_DETECTION) return

            val detectedHero = parseCards(intent.getStringExtra(ScreenCaptureService.EXTRA_HERO).orEmpty())
            val detectedBoardRaw = parseCards(intent.getStringExtra(ScreenCaptureService.EXTRA_BOARD).orEmpty())
            val heroConf = intent.getStringExtra(ScreenCaptureService.EXTRA_HERO_CONF).orEmpty()
            val boardConf = intent.getStringExtra(ScreenCaptureService.EXTRA_BOARD_CONF).orEmpty()
            val heroMinConf = intent.getFloatExtra(ScreenCaptureService.EXTRA_HERO_MIN_CONF, 0f)
            val boardMinConf = intent.getFloatExtra(ScreenCaptureService.EXTRA_BOARD_MIN_CONF, 0f)
            val debug = intent.getStringExtra(ScreenCaptureService.EXTRA_DEBUG).orEmpty()
            val savedPath = intent.getStringExtra(ScreenCaptureService.EXTRA_SAVED_PATH).orEmpty()

            if (!heroLocked && detectedHero.size >= 2 && heroMinConf >= 0.58f && detectedHero.distinct().size == detectedHero.size) {
                hero.clear()
                hero.addAll(detectedHero.take(2))
                board.removeAll { it in hero }
            }

            val detectedBoard = detectedBoardRaw.filterNot { it in hero }.distinct().take(5)
            val validBoardSize = detectedBoard.size == 3 || detectedBoard.size == 4 || detectedBoard.size == 5
            val isNextStreet = when (board.size) {
                0 -> detectedBoard.size == 3 || detectedBoard.size == 4 || detectedBoard.size == 5
                3 -> detectedBoard.size == 3 || detectedBoard.size == 4 || detectedBoard.size == 5
                4 -> detectedBoard.size == 4 || detectedBoard.size == 5
                5 -> detectedBoard.size == 5
                else -> validBoardSize
            }
            if (validBoardSize && isNextStreet && boardMinConf >= 0.50f) {
                board.clear()
                board.addAll(detectedBoard)
            }

            autoText.text = buildString {
                append("אוטומטי: ${debug.ifBlank { "פעיל" }}")
                if (heroConf.isNotBlank()) append("\nשלי ביטחון: $heroConf")
                if (boardConf.isNotBlank()) append("\nשולחן ביטחון: $boardConf")
                if (heroMinConf in 0.01f..0.57f) append("\nלא החלפתי יד - ביטחון נמוך")
                if (boardMinConf in 0.01f..0.49f) append("\nלא החלפתי שולחן - ביטחון נמוך")
                if (detectedBoardRaw.size in 1..2) append("\nהתעלמתי מלוח 1–2 קלפים")
                if (savedPath.isNotBlank()) append("\nנשמר פריים")
            }
            updateResult()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        root = buildView()
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(24)
            y = dp(90)
        }
        root.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = e.rawX
                    touchY = e.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (e.rawX - touchX).toInt()
                    params.y = startY + (e.rawY - touchY).toInt()
                    runCatching { wm.updateViewLayout(root, params) }
                    true
                }
                else -> false
            }
        }
        runCatching { wm.addView(root, params) }
            .onFailure { ErrorReporter.report(this, "חלון צף", it, "לא הצלחתי להציג חלון צף") }

        val filter = IntentFilter(ScreenCaptureService.ACTION_DETECTION).apply {
            addAction(ScreenCaptureService.ACTION_STATUS)
            addAction(ErrorReporter.ACTION_ERROR)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) registerReceiver(detectionReceiver, filter, RECEIVER_NOT_EXPORTED)
        else registerReceiver(detectionReceiver, filter)
    }

    private fun buildView(): LinearLayout {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(0xF20B1020.toInt(), 24f, 0xFF38BDF8.toInt())
        }

        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply {
            text = "♠ מאמן פוקר"
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFFFFFFFF.toInt())
        }
        compactBtn = smallButton("קומפקטי") { toggleCompact() }
        val closeBtn = smallButton("סגור") { sendCaptureAction(ScreenCaptureService.ACTION_STOP); stopSelf() }
        header.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(compactBtn)
        header.addView(closeBtn)

        compactText = TextView(this).apply {
            text = "Win 0% | Future 0%"
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, dp(8), 0, dp(6))
        }

        autoText = TextView(this).apply {
            text = "אוטומטי: ממתין"
            textSize = 11f
            setTextColor(0xFF93C5FD.toInt())
            setPadding(0, dp(2), 0, dp(4))
        }
        resultText = TextView(this).apply {
            text = "בחר 2 קלפים שלך"
            textSize = 13f
            setTextColor(0xFFE5E7EB.toInt())
            setPadding(0, dp(4), 0, dp(6))
        }

        winTitle = barTitle("סיכוי זכייה עכשיו: 0%")
        winBar = bar()
        strengthTitle = barTitle("חוזק יד: 0/100")
        strengthBar = bar()
        futureTitle = barTitle("עתידי: קלף הבא 0% | עד הריבר 0%")
        nextBar = bar()
        riverBar = bar()

        detailsContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(resultText)
            addView(winTitle); addView(winBar)
            addView(strengthTitle); addView(strengthBar)
            addView(futureTitle); addView(nextBar); addView(riverBar)
        }

        controlsContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val row1 = buttonRow(
            smallButton("קלף שלי") { showCardPicker(true) },
            smallButton("שולחן") { showCardPicker(false) }
        )
        lockBtn = smallButton("נעל: כבוי") {
            heroLocked = !heroLocked
            lockBtn.text = if (heroLocked) "נעל: פעיל" else "נעל: כבוי"
            updateResult()
        }
        profileBtn = smallButton("מסך: אוטו") { cycleProfile() }
        val row2 = buttonRow(lockBtn, profileBtn)
        val calibrateBtn = smallButton("כיול מיקומים") { openCalibration() }

        val oppLabel = TextView(this).apply {
            text = "שחקנים: $opponents"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
        }
        val minus = smallButton("-") { opponents = (opponents - 1).coerceAtLeast(1); oppLabel.text = "שחקנים: $opponents"; updateResult() }
        val plus = smallButton("+") { opponents = (opponents + 1).coerceAtMost(8); oppLabel.text = "שחקנים: $opponents"; updateResult() }
        val oppRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(minus)
            addView(oppLabel, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(plus)
        }
        val row3 = buttonRow(
            smallButton("שמור פריים") { sendCaptureAction(ScreenCaptureService.ACTION_SAVE_NEXT_FRAME); autoText.text = "אוטומטי: הפריים הבא יישמר" },
            smallButton("עצור זיהוי") { sendCaptureAction(ScreenCaptureService.ACTION_STOP); autoText.text = "אוטומטי: נעצר" }
        )
        val clearBtn = smallButton("איפוס יד") {
            heroLocked = false
            hero.clear()
            board.clear()
            lockBtn.text = "נעל: כבוי"
            autoText.text = "אוטומטי: אופס, מחכה ליד חדשה"
            profileMode = "auto"
            profileBtn.text = "מסך: אוטו"
            updateResult()
        }

        controlsContainer.addView(row1)
        controlsContainer.addView(row2)
        controlsContainer.addView(calibrateBtn)
        controlsContainer.addView(oppRow)
        controlsContainer.addView(row3)
        controlsContainer.addView(clearBtn)

        layout.addView(header)
        layout.addView(compactText)
        layout.addView(autoText)
        layout.addView(detailsContainer)
        layout.addView(controlsContainer)
        return layout
    }

    private fun toggleCompact() {
        compactMode = !compactMode
        compactBtn.text = if (compactMode) "מלא" else "קומפקטי"
        detailsContainer.visibility = if (compactMode) android.view.View.GONE else android.view.View.VISIBLE
        controlsContainer.visibility = if (compactMode) android.view.View.GONE else android.view.View.VISIBLE
    }

    private fun cycleProfile() {
        val hasCustom = CalibrationStore.isEnabled(this)
        profileMode = when (profileMode) {
            "auto" -> "green_table"
            "green_table" -> "pokerface_red_table"
            "pokerface_red_table" -> if (hasCustom) "custom" else "auto"
            else -> "auto"
        }
        profileBtn.text = when (profileMode) {
            "green_table" -> "מסך: ירוק"
            "pokerface_red_table" -> "מסך: אדום"
            "custom" -> "מסך: מותאם"
            else -> "מסך: אוטו"
        }
        sendCaptureAction(ScreenCaptureService.ACTION_SET_PROFILE, profileMode)
    }

    private fun openCalibration() {
        runCatching {
            startService(Intent(this, CalibrationOverlayService::class.java))
        }.onSuccess {
            autoText.text = "אוטומטי: מצב כיול נפתח"
        }.onFailure {
            ErrorReporter.report(this, "כיול מיקומים", it, "לא הצלחתי לפתוח כיול מיקומים")
            autoText.text = "בעיה בפתיחת כיול"
        }
    }

    private fun sendCaptureAction(action: String, profile: String? = null) {
        runCatching {
            startService(Intent(this, ScreenCaptureService::class.java).apply {
                this.action = action
                if (profile != null) putExtra(ScreenCaptureService.EXTRA_PROFILE, profile)
            })
        }.onFailure {
            ErrorReporter.report(this, "פעולה לזיהוי", it, "שגיאה בשליחת פעולה לזיהוי")
            autoText.text = "שגיאה בשליחת פעולה: ${it.message ?: "לא ידוע"}"
        }
    }

    private fun buttonRow(first: Button, second: Button): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER
        setPadding(0, dp(3), 0, dp(3))
        addView(first, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(4) })
        addView(second, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(4) })
    }

    private fun barTitle(textValue: String): TextView = TextView(this).apply {
        text = textValue
        textSize = 12f
        setTextColor(0xFFFFFFFF.toInt())
        setPadding(0, dp(6), 0, dp(2))
    }

    private fun bar(): ProgressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
        max = 100
        progress = 0
        layoutParams = LinearLayout.LayoutParams(dp(285), dp(18))
    }

    private fun smallButton(textValue: String, action: () -> Unit): Button = Button(this).apply {
        text = textValue
        textSize = 12f
        setTextColor(0xFFFFFFFF.toInt())
        background = rounded(0xFF1F2937.toInt(), 14f, 0xFF4B5563.toInt())
        minHeight = dp(36)
        minWidth = dp(58)
        setPadding(dp(5), dp(4), dp(5), dp(4))
        setOnClickListener { action() }
    }

    private fun rounded(color: Int, radius: Float, stroke: Int): GradientDrawable = GradientDrawable().apply {
        cornerRadius = radius
        setColor(color)
        setStroke(dp(1), stroke)
    }

    private fun showCardPicker(isHero: Boolean) {
        val popup = PopupWindow(this)
        val wrapper = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFFFFFFF.toInt())
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        val hint = TextView(this).apply {
            text = if (isHero) "בחר קלף שלי" else "בחר קלף שולחן"
            setTextColor(0xFF111111.toInt())
            typeface = Typeface.DEFAULT_BOLD
            textSize = 15f
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        val grid = GridLayout(this).apply { columnCount = 4; setPadding(dp(4), dp(4), dp(4), dp(4)) }
        Rank.allDesc.forEach { r ->
            Suit.entries.forEach { s ->
                val card = Card(r, s)
                val b = Button(this).apply {
                    text = card.toString()
                    textSize = 13f
                    setTextColor(if (s == Suit.HEARTS || s == Suit.DIAMONDS) 0xFFB00020.toInt() else 0xFF111111.toInt())
                    setOnClickListener {
                        if ((hero + board).contains(card)) {
                            Toast.makeText(this@FloatingOverlayService, "הקלף כבר קיים ביד הזאת", Toast.LENGTH_SHORT).show()
                            popup.dismiss()
                            return@setOnClickListener
                        }
                        if (isHero) {
                            if (hero.size >= 2) hero.removeAt(0)
                            hero.add(card)
                            board.removeAll { it in hero }
                        } else {
                            if (board.size >= 5) board.removeAt(0)
                            board.add(card)
                        }
                        popup.dismiss()
                        updateResult()
                    }
                }
                grid.addView(b)
            }
        }
        wrapper.addView(hint)
        wrapper.addView(ScrollView(this).apply { addView(grid) })
        popup.contentView = wrapper
        popup.width = dp(330)
        popup.height = dp(520)
        popup.isOutsideTouchable = true
        popup.isFocusable = true
        runCatching { popup.showAtLocation(root, Gravity.CENTER, 0, 0) }
            .onFailure { ErrorReporter.report(this, "בחירת קלף", it, "לא הצלחתי לפתוח בחירת קלפים") }
    }

    private fun updateResult() {
        if (hero.size < 2) {
            compactText.text = "בחר 2 קלפים"
            resultText.text = "קלפים שלי: ${hero.joinToString(" ")}\nבחר 2 קלפים שלך"
            winTitle.text = "סיכוי זכייה עכשיו: 0%"
            winBar.progress = 0
            strengthTitle.text = "חוזק יד: 0/100"
            strengthBar.progress = 0
            futureTitle.text = "עתידי: קלף הבא 0% | עד הריבר 0%"
            nextBar.progress = 0
            riverBar.progress = 0
            return
        }

        val seq = analysisSeq.incrementAndGet()
        val heroSnapshot = hero.toList()
        val boardSnapshot = normalizeBoardForAnalyze(board.toList())
        val opponentsSnapshot = opponents
        val lockedSnapshot = heroLocked
        compactText.text = "מחשב..."
        resultText.text = "שלי: ${heroSnapshot.joinToString(" ")} ${if (lockedSnapshot) "🔒" else ""}\nמחשב אחוזים..."

        analyzerExecutor.execute {
            val analysis = runCatching { analyzer.analyze(heroSnapshot, boardSnapshot, opponentsSnapshot) }
            val stage = when (boardSnapshot.size) {
                0 -> "לפני פלופ"
                3 -> "פלופ"
                4 -> "טרן"
                5 -> "ריבר"
                else -> "שולחן ${boardSnapshot.size}"
            }
            uiHandler.post {
                if (seq != analysisSeq.get()) return@post
                val res = analysis.getOrNull()
                if (res == null) {
                    val err = analysis.exceptionOrNull()
                    if (err != null) ErrorReporter.report(this@FloatingOverlayService, "חישוב אחוזים", err, "שגיאה בחישוב יד")
                    compactText.text = "בעיה בחישוב"
                    resultText.text = "בעיה בחישוב אחוזים. נסה איפוס יד ובחירת קלפים מחדש."
                    autoText.text = "שגיאה: חישוב אחוזים נכשל"
                    return@post
                }
                val future = maxOf(res.improveNextCardPercent, res.improveToRiverPercent)
                compactText.text = "Win ${res.winChancePercent}% | Future $future%"
                resultText.text = buildString {
                    append("שלי: ${heroSnapshot.joinToString(" ")} ${if (lockedSnapshot) "🔒" else ""}")
                    append("\nשולחן: ${if (boardSnapshot.isEmpty()) "-" else boardSnapshot.joinToString(" ")}")
                    append("\nשלב: $stage | יד: ${res.category}")
                    append("\n${res.actionLabel}")
                    append("\n${res.explanation}")
                    if (res.outs > 0) append("\nOuts: ${res.outs}")
                    if (res.draws.isNotEmpty()) append(" | ${res.draws.joinToString(", ")}")
                }
                winTitle.text = "סיכוי זכייה עכשיו: ${res.winChancePercent}%"
                winBar.progress = res.winChancePercent.coerceIn(0, 100)
                strengthTitle.text = "חוזק יד: ${res.strengthScore}/100"
                strengthBar.progress = res.strengthScore.coerceIn(0, 100)
                futureTitle.text = "עתידי: קלף הבא ${res.improveNextCardPercent}% | עד הריבר ${res.improveToRiverPercent}%"
                nextBar.progress = res.improveNextCardPercent.coerceIn(0, 100)
                riverBar.progress = res.improveToRiverPercent.coerceIn(0, 100)
            }
        }
    }

    private fun normalizeBoardForAnalyze(raw: List<Card>): List<Card> {
        val unique = raw.distinct().take(5)
        return when (unique.size) {
            0, 3, 4, 5 -> unique
            1, 2 -> emptyList()
            else -> unique.take(5)
        }
    }

    private fun parseCards(raw: String): List<Card> {
        if (raw.isBlank()) return emptyList()
        return raw.split(",").mapNotNull { token ->
            val t = token.trim()
            if (t.length < 2) return@mapNotNull null
            val suitSymbol = t.last().toString()
            val rankLabel = t.dropLast(1)
            val rank = Rank.entries.firstOrNull { it.label == rankLabel } ?: return@mapNotNull null
            val suit = Suit.entries.firstOrNull { it.symbol == suitSymbol } ?: return@mapNotNull null
            Card(rank, suit)
        }.distinct()
    }

    override fun onDestroy() {
        analysisSeq.incrementAndGet()
        analyzerExecutor.shutdownNow()
        runCatching { unregisterReceiver(detectionReceiver) }
            .onFailure { ErrorReporter.report(this, "סגירת חלון", it, "בעיה בביטול מאזין") }
        if (::root.isInitialized) runCatching { wm.removeView(root) }
            .onFailure { ErrorReporter.report(this, "סגירת חלון", it, "בעיה בהסרת חלון צף") }
        super.onDestroy()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
