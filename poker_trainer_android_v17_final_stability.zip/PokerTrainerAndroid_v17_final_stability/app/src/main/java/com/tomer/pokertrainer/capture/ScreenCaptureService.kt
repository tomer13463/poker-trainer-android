package com.tomer.pokertrainer.capture

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.tomer.pokertrainer.detect.CardDetector
import com.tomer.pokertrainer.util.ErrorReporter
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicBoolean

class ScreenCaptureService : Service() {
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private val detector = CardDetector()
    private val mainHandler = Handler(Looper.getMainLooper())
    private lateinit var captureThread: HandlerThread
    private lateinit var captureHandler: Handler
    private val isProcessingFrame = AtomicBoolean(false)
    private var lastAnalyzeAt = 0L
    private var forcedProfile: String = "auto"
    private var saveNextFrame = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        captureThread = HandlerThread("PokerTrainerCaptureThread").apply { start() }
        captureHandler = Handler(captureThread.looper)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                sendBroadcast(Intent(ACTION_STATUS).apply { putExtra(EXTRA_STATUS, "זיהוי נעצר") })
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_SET_PROFILE -> {
                forcedProfile = intent.getStringExtra(EXTRA_PROFILE) ?: "auto"
                sendBroadcast(Intent(ACTION_STATUS).apply { putExtra(EXTRA_STATUS, "פרופיל עודכן: $forcedProfile") })
                return START_STICKY
            }
            ACTION_SAVE_NEXT_FRAME -> {
                saveNextFrame = true
                sendBroadcast(Intent(ACTION_STATUS).apply { putExtra(EXTRA_STATUS, "הפריים הבא יישמר לדיבאג") })
                return START_STICKY
            }
        }

        createChannel()
        startForeground(7, NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("מאמן פוקר פעיל")
            .setContentText("זיהוי לימודי מסרטון במסך")
            .setOngoing(true)
            .build())

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val data = readProjectionData(intent)
        if (resultCode != 0 && data != null && projection == null) {
            runCatching { startProjection(resultCode, data) }
                .onFailure {
                    ErrorReporter.report(this, "צילום מסך", it, "שגיאה בהפעלת צילום מסך")
                    sendBroadcast(Intent(ACTION_STATUS).apply { putExtra(EXTRA_STATUS, "שגיאה בהפעלת צילום מסך: ${it.message ?: "לא ידוע"}") })
                    stopSelf()
                }
        }
        return START_STICKY
    }

    private fun readProjectionData(intent: Intent?): Intent? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_DATA)
        }
    }

    private fun startProjection(resultCode: Int, data: Intent) {
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(resultCode, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                mainHandler.post { stopSelf() }
            }
        }, captureHandler)
        val metrics = resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        imageReader?.setOnImageAvailableListener({ reader ->
            val now = System.currentTimeMillis()
            val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            var bitmap: Bitmap? = null
            var cropped: Bitmap? = null
            try {
                if (now - lastAnalyzeAt < 850) return@setOnImageAvailableListener
                if (!isProcessingFrame.compareAndSet(false, true)) return@setOnImageAvailableListener
                lastAnalyzeAt = now

                val plane = image.planes[0]
                val buffer = plane.buffer
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                val rowPadding = rowStride - pixelStride * width
                bitmap = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888)
                bitmap.copyPixelsFromBuffer(buffer)
                cropped = Bitmap.createBitmap(bitmap, 0, 0, width, height)

                var savedPath = ""
                if (saveNextFrame) {
                    savedPath = saveDebugFrame(cropped)
                    saveNextFrame = false
                }

                val result = detector.detect(cropped, forcedProfile, this@ScreenCaptureService)
                sendBroadcast(Intent(ACTION_DETECTION).apply {
                    putExtra(EXTRA_HERO, result.heroCards.joinToString(",") { it.card.toString() })
                    putExtra(EXTRA_BOARD, result.boardCards.joinToString(",") { it.card.toString() })
                    putExtra(EXTRA_HERO_CONF, result.heroConfidenceText)
                    putExtra(EXTRA_BOARD_CONF, result.boardConfidenceText)
                    putExtra(EXTRA_HERO_MIN_CONF, result.heroCards.minOfOrNull { it.confidence } ?: 0f)
                    putExtra(EXTRA_BOARD_MIN_CONF, result.boardCards.minOfOrNull { it.confidence } ?: 0f)
                    putExtra(EXTRA_DEBUG, result.debugText)
                    putExtra(EXTRA_SAVED_PATH, savedPath)
                })
            } catch (t: Throwable) {
                ErrorReporter.report(this@ScreenCaptureService, "זיהוי קלפים", t, "שגיאת זיהוי בפריים")
                sendBroadcast(Intent(ACTION_STATUS).apply { putExtra(EXTRA_STATUS, "שגיאת זיהוי: ${t.message ?: "לא ידוע"}") })
            } finally {
                cropped?.recycle()
                bitmap?.recycle()
                isProcessingFrame.set(false)
                image.close()
            }
        }, captureHandler)

        virtualDisplay = projection?.createVirtualDisplay(
            "PokerTrainerCapture",
            width,
            height,
            density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            captureHandler
        )
    }

    private fun saveDebugFrame(frame: Bitmap): String {
        return runCatching {
            val dir = File(getExternalFilesDir(null), "debug_frames")
            dir.mkdirs()
            val file = File(dir, "poker_frame_${System.currentTimeMillis()}.png")
            FileOutputStream(file).use { out -> frame.compress(Bitmap.CompressFormat.PNG, 100, out) }
            file.absolutePath
        }.getOrElse {
            ErrorReporter.report(this, "שמירת דיבאג", it, "לא הצלחתי לשמור פריים דיבאג")
            "שגיאה בשמירה: ${it.message ?: "לא ידוע"}"
        }
    }

    override fun onDestroy() {
        runCatching { virtualDisplay?.release() }.onFailure { ErrorReporter.report(this, "סגירת צילום", it, "בעיה בסגירת VirtualDisplay") }
        runCatching { imageReader?.close() }.onFailure { ErrorReporter.report(this, "סגירת צילום", it, "בעיה בסגירת ImageReader") }
        runCatching { projection?.stop() }.onFailure { ErrorReporter.report(this, "סגירת צילום", it, "בעיה בסגירת MediaProjection") }
        virtualDisplay = null
        imageReader = null
        projection = null
        if (::captureThread.isInitialized) runCatching { captureThread.quitSafely() }
            .onFailure { ErrorReporter.report(this, "סגירת צילום", it, "בעיה בסגירת CaptureThread") }
        super.onDestroy()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Poker Trainer", NotificationManager.IMPORTANCE_LOW))
        }
    }

    companion object {
        const val ACTION_DETECTION = "com.tomer.pokertrainer.ACTION_DETECTION"
        const val ACTION_STATUS = "com.tomer.pokertrainer.ACTION_STATUS"
        const val ACTION_STOP = "com.tomer.pokertrainer.ACTION_STOP_CAPTURE"
        const val ACTION_SET_PROFILE = "com.tomer.pokertrainer.ACTION_SET_PROFILE"
        const val ACTION_SAVE_NEXT_FRAME = "com.tomer.pokertrainer.ACTION_SAVE_NEXT_FRAME"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_DATA = "data"
        const val EXTRA_HERO = "hero"
        const val EXTRA_BOARD = "board"
        const val EXTRA_HERO_CONF = "heroConf"
        const val EXTRA_BOARD_CONF = "boardConf"
        const val EXTRA_HERO_MIN_CONF = "heroMinConf"
        const val EXTRA_BOARD_MIN_CONF = "boardMinConf"
        const val EXTRA_STATUS = "status"
        const val EXTRA_DEBUG = "debug"
        const val EXTRA_PROFILE = "profile"
        const val EXTRA_SAVED_PATH = "savedPath"
        private const val CHANNEL_ID = "poker_trainer_capture"
    }
}
