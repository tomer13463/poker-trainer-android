package com.tomer.pokertrainer

import android.app.Application
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import com.tomer.pokertrainer.util.ErrorReporter

class PokerTrainerApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val oldHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            ErrorReporter.report(this, "קריסה כללית", throwable, "האפליקציה קרסה. נשמר לוג שגיאה לבדיקה.")
            runCatching {
                Handler(Looper.getMainLooper()).post {
                    Toast.makeText(this, "האפליקציה נתקלה בשגיאה. פתח שוב ושלח צילום של הודעת השגיאה.", Toast.LENGTH_LONG).show()
                }
            }
            oldHandler?.uncaughtException(thread, throwable)
        }
    }
}
