package com.tomer.pokertrainer.poker

import com.tomer.pokertrainer.model.Card

class PokerHandEvaluator {
    fun evaluate(cards: List<Card>): Pair<Int, String> {
        if (cards.isEmpty()) return 0 to "אין קלפים"

        val rankCounts = cards.groupingBy { it.rank.value }.eachCount()
        val ranksDesc = rankCounts.keys.sortedDescending()
        val suitGroups = cards.groupBy { it.suit }
        val flushCards = suitGroups.values
            .filter { it.size >= 5 }
            .maxByOrNull { group -> group.maxOf { it.rank.value } }
            ?: emptyList()

        val straightFlushHigh = if (flushCards.size >= 5) {
            straightHigh(flushCards.map { it.rank.value }.distinct())
        } else null

        if (straightFlushHigh != null) {
            return if (straightFlushHigh == 14) {
                encode(9, listOf(14)) to "Royal Flush"
            } else {
                encode(8, listOf(straightFlushHigh)) to "Straight Flush"
            }
        }

        val quads = rankCounts.filterValues { it == 4 }.keys.sortedDescending()
        if (quads.isNotEmpty()) {
            val quad = quads.first()
            val kicker = ranksDesc.firstOrNull { it != quad } ?: 0
            return encode(7, listOf(quad, kicker)) to "Four of a Kind"
        }

        val trips = rankCounts.filterValues { it >= 3 }.keys.sortedDescending()
        val pairs = rankCounts.filterValues { it >= 2 }.keys.sortedDescending()
        if (trips.isNotEmpty()) {
            val trip = trips.first()
            val fullHousePair = (trips.drop(1) + pairs.filter { it != trip }).maxOrNull()
            if (fullHousePair != null) {
                return encode(6, listOf(trip, fullHousePair)) to "Full House"
            }
        }

        if (flushCards.size >= 5) {
            val topFlush = flushCards.map { it.rank.value }.distinct().sortedDescending().take(5)
            return encode(5, topFlush) to "Flush"
        }

        val straightHigh = straightHigh(ranksDesc)
        if (straightHigh != null) {
            return encode(4, listOf(straightHigh)) to "Straight"
        }

        if (trips.isNotEmpty()) {
            val trip = trips.first()
            val kickers = ranksDesc.filter { it != trip }.take(2)
            return encode(3, listOf(trip) + kickers) to "Three of a Kind"
        }

        if (pairs.size >= 2) {
            val topPairs = pairs.take(2)
            val kicker = ranksDesc.firstOrNull { it !in topPairs } ?: 0
            return encode(2, topPairs + kicker) to "Two Pair"
        }

        if (pairs.size == 1) {
            val pair = pairs.first()
            val kickers = ranksDesc.filter { it != pair }.take(3)
            return encode(1, listOf(pair) + kickers) to "One Pair"
        }

        return encode(0, ranksDesc.take(5)) to "High Card"
    }

    private fun encode(category: Int, kickers: List<Int>): Int {
        var kickerValue = 0
        val padded = (kickers + List(5) { 0 }).take(5)
        for (k in padded) kickerValue = kickerValue * 15 + k
        return category * 1_000_000 + kickerValue
    }

    private fun straightHigh(ranks: List<Int>): Int? {
        val set = ranks.toMutableSet()
        if (14 in set) set.add(1)
        for (high in 14 downTo 5) {
            if ((0..4).all { high - it in set }) return high
        }
        return null
    }
}
