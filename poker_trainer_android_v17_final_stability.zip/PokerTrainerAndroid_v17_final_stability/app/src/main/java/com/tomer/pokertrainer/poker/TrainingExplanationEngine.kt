package com.tomer.pokertrainer.poker

import com.tomer.pokertrainer.model.Card

class TrainingExplanationEngine {
    fun build(
        category: String,
        win: Int,
        improveNext: Int,
        improveRiver: Int,
        outs: Int,
        draws: List<String>,
        hero: List<Card>,
        board: List<Card>
    ): Pair<String, String> {
        val stage = when (board.size) { 0 -> "לפני פלופ"; 3 -> "פלופ"; 4 -> "טרן"; 5 -> "ריבר"; else -> "יד חלקית" }
        val action = when {
            win >= 75 -> "פרימיום - יתרון חזק"
            win >= 60 -> "חזק - אפשר לחשוב אגרסיבי"
            win >= 45 -> "בינוני - לשלם בזהירות"
            win >= 30 -> "גבולי - להיזהר"
            else -> "חלש - לרוב עדיף לקפל"
        }
        val drawText = if (draws.isEmpty()) "אין Draw חזק" else draws.joinToString(" / ")
        val futureText = if (board.size < 5) "קלף הבא: $improveNext%, עד הריבר: $improveRiver%." else "אין עוד קלפים להיפתח."
        val risk = when {
            win >= 65 -> "סיכון נמוך"
            win >= 45 -> "סיכון בינוני"
            win >= 30 -> "סיכון גבוה"
            else -> "סיכון גבוה מאוד"
        }
        val explanation = "מצב: $stage. יד: $category. $risk. $drawText. Outs: $outs. שיפור: $futureText"
        return action to explanation
    }
}
