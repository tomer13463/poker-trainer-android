package com.tomer.pokertrainer.poker

import com.tomer.pokertrainer.model.Card
import com.tomer.pokertrainer.model.Rank
import com.tomer.pokertrainer.model.Suit

class OutsCalculator(private val evaluator: PokerHandEvaluator = PokerHandEvaluator()) {
    private val fullDeck = Rank.entries.flatMap { r -> Suit.entries.map { s -> Card(r, s) } }

    fun drawsAndOuts(hero: List<Card>, board: List<Card>): Pair<List<String>, Int> {
        if (hero.size != 2) return emptyList<String>() to 0
        if (board.size >= 5) return emptyList<String>() to 0

        val cards = hero + board
        val used = cards.toSet()
        val deck = fullDeck.filterNot { it in used }
        val current = evaluator.evaluate(cards).first
        val currentCategory = current / 1_000_000

        val draws = mutableListOf<String>()
        val cleanOutCards = linkedSetOf<Card>()

        // Flush draw: only count it strong if hero participates in the suit.
        val suitGroups = cards.groupBy { it.suit }
        suitGroups.forEach { (suit, suitedCards) ->
            val heroInSuit = hero.count { it.suit == suit }
            if (suitedCards.size == 4 && heroInSuit > 0) {
                draws.add("Flush Draw")
                cleanOutCards.addAll(deck.filter { it.suit == suit })
            } else if (suitedCards.size == 3 && heroInSuit > 0 && board.size <= 3) {
                draws.add("Backdoor Flush")
            }
        }

        // Straight draws.
        val ranks = cards.map { it.rank.value }.toMutableSet()
        if (14 in ranks) ranks.add(1)
        val windows = (5..14).map { high -> (0..4).map { high - it }.toSet() }
        for (w in windows) {
            val missing = w.filterNot { it in ranks }
            if (missing.size == 1) {
                val missingRank = if (missing.first() == 1) 14 else missing.first()
                val isOpenEnded = missing.first() != w.minOrNull() && missing.first() != w.maxOrNull()
                draws.add(if (isOpenEnded) "Open Straight Draw" else "Gutshot Straight Draw")
                cleanOutCards.addAll(deck.filter { it.rank.value == missingRank })
            }
        }

        // Overcards on flop/turn: useful but weaker outs, still show as potential.
        val boardHigh = board.maxOfOrNull { it.rank.value } ?: 0
        if (board.isNotEmpty()) {
            val overcards = hero.filter { it.rank.value > boardHigh }.map { it.rank.value }.distinct()
            if (overcards.isNotEmpty() && currentCategory == 0) {
                draws.add("Overcards")
                cleanOutCards.addAll(deck.filter { it.rank.value in overcards })
            }
        }

        // Real improvement outs by evaluator, then filter and combine with draw outs.
        val evaluatorOuts = deck.filter { evaluator.evaluate(cards + it).first > current }
        cleanOutCards.addAll(evaluatorOuts)

        if (board.isEmpty()) draws.add("Preflop potential")

        return draws.distinct() to cleanOutCards.size.coerceIn(0, deck.size)
    }
}
