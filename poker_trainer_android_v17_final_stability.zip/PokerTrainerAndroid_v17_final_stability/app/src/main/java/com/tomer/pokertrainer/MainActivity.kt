package com.tomer.pokertrainer

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.tomer.pokertrainer.capture.ScreenCaptureService
import com.tomer.pokertrainer.overlay.FloatingOverlayService
import com.tomer.pokertrainer.util.ErrorReporter
import com.tomer.pokertrainer.util.CalibrationStore
import com.tomer.pokertrainer.overlay.CalibrationOverlayService

class MainActivity : AppCompatActivity() {
    private val captureRequestCode = 9101
    private lateinit var statusText: TextView
    private lateinit var errorText: TextView
    private lateinit var overlayPermissionCard: TextView
    private lateinit var capturePermissionCard: TextView

    private val errorReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != ErrorReporter.ACTION_ERROR) return
            val area = intent.getStringExtra(ErrorReporter.EXTRA_AREA).orEmpty()
            val msg = intent.getStringExtra(ErrorReporter.EXTRA_MESSAGE).orEmpty()
            errorText.text = "בעיה: $area\n$msg"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        runCatching { buildMainUi() }.onFailure {
            ErrorReporter.report(this, "פתיחת מסך ראשי", it, "בעיה בטעינת מסך ראשי")
            Toast.makeText(this, "בעיה בטעינת האפליקציה: ${it.message ?: "לא ידוע"}", Toast.LENGTH_LONG).show()
        }
        requestNotificationPermissionIfNeeded()
    }

    override fun onResume() {
        super.onResume()
        if (::overlayPermissionCard.isInitialized) updatePermissionCards()
    }

    private fun buildMainUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(24))
            setBackgroundColor(0xFF0B1020.toInt())
        }

        val title = TextView(this).apply {
            text = "מאמן פוקר אישי"
            textSize = 27f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
        }
        val subtitle = TextView(this).apply {
            text = "בחר מה האפליקציה תעשה: חלון ידני, זיהוי אוטומטי מסרטונים, דיבאג ושגיאות."
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(0xFFD6E4FF.toInt())
            setPadding(0, dp(6), 0, dp(16))
        }

        statusText = TextView(this).apply {
            text = "מוכן לבדיקה. מומלץ להתחיל ממצב ידני ואז לעבור לאוטומטי."
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(0xFF14213D.toInt(), 18f, 0xFF2F80ED.toInt())
        }

        overlayPermissionCard = smallStatus("חלון צף: בודק…")
        capturePermissionCard = smallStatus("צילום מסך: ייבקש אישור בהפעלה")

        val modeTitle = sectionTitle("מצבי עבודה")
        val manualBtn = primaryButton("פתח חלון ידני") { openOverlayOnly() }
        val autoBtn = primaryButton("פתח חלון + זיהוי אוטומטי") { startAutoMode() }
        val calibrateBtn = secondaryButton("כיול מיקומים ידני") { openCalibrationMode() }
        val stopBtn = secondaryButton("עצור זיהוי ברקע") {
            runCatching { startService(Intent(this, ScreenCaptureService::class.java).apply { action = ScreenCaptureService.ACTION_STOP }) }
            statusText.text = "זיהוי ברקע נעצר."
        }

        val toolsTitle = sectionTitle("כלים ותיקון בעיות")
        val permissionBtn = secondaryButton("פתח הרשאת חלון צף") { openOverlayPermissionSettings() }
        val clearCalibrationBtn = secondaryButton("נקה כיול מותאם") {
            CalibrationStore.clear(this@MainActivity)
            statusText.text = "הכיול המותאם נמחק. אפשר ליצור כיול חדש."
        }
        val showLastErrorBtn = secondaryButton("הצג שגיאה אחרונה") {
            val last = ErrorReporter.lastError(this@MainActivity)
            errorText.text = if (last.isBlank()) "אין שגיאות אחרונות" else "שגיאה אחרונה:\n${last.take(1800)}"
        }
        val clearErrorBtn = secondaryButton("נקה שגיאות") {
            ErrorReporter.clear(this@MainActivity)
            errorText.text = "אין שגיאות אחרונות"
        }

        val featuresTitle = sectionTitle("מה יש באפליקציה")
        val features = TextView(this).apply {
            text = "• פס סיכוי זכייה עכשיו\n• פס חוזק יד 0–100\n• פוטנציאל עתידי: קלף הבא / עד הריבר\n• בחירת קלפים ידנית לתיקון מהיר\n• זיהוי אוטומטי למסכים: אוטומטי / שולחן ירוק / PokerFace אדום / מותאם\n• כיול מיקומים ידני עם מסגרות לגרירה והגדלה/הקטנה\n• שמירת פריים דיבאג כשיש טעות\n• הודעות שגיאה מובנות"
            textSize = 14f
            setTextColor(0xFFE8F1FF.toInt())
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(0xFF111827.toInt(), 18f, 0xFF374151.toInt())
        }

        errorText = TextView(this).apply {
            val last = ErrorReporter.lastError(this@MainActivity)
            text = if (last.isBlank()) "אין שגיאות אחרונות" else "שגיאה אחרונה:\n${last.take(900)}"
            textSize = 12f
            setTextColor(0xFFFFB4AB.toInt())
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = rounded(0xFF2A1111.toInt(), 16f, 0xFF7F1D1D.toInt())
        }

        root.addView(title)
        root.addView(subtitle)
        root.addView(statusText)
        root.addView(row(overlayPermissionCard, capturePermissionCard))
        root.addView(modeTitle)
        root.addView(manualBtn)
        root.addView(autoBtn)
        root.addView(calibrateBtn)
        root.addView(stopBtn)
        root.addView(toolsTitle)
        root.addView(permissionBtn)
        root.addView(clearCalibrationBtn)
        root.addView(showLastErrorBtn)
        root.addView(clearErrorBtn)
        root.addView(featuresTitle)
        root.addView(features)
        root.addView(sectionTitle("שגיאות"))
        root.addView(errorText)

        setContentView(ScrollView(this).apply { addView(root) })
        updatePermissionCards()
    }

    private fun row(a: TextView, b: TextView): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER
        setPadding(0, dp(12), 0, dp(4))
        addView(a, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(6) })
        addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(6) })
    }

    private fun sectionTitle(textValue: String): TextView = TextView(this).apply {
        text = textValue
        textSize = 18f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(0xFFFFFFFF.toInt())
        setPadding(0, dp(18), 0, dp(8))
    }

    private fun smallStatus(textValue: String): TextView = TextView(this).apply {
        text = textValue
        textSize = 12f
        gravity = Gravity.CENTER
        setTextColor(0xFFFFFFFF.toInt())
        setPadding(dp(8), dp(10), dp(8), dp(10))
        background = rounded(0xFF1F2937.toInt(), 16f, 0xFF374151.toInt())
    }

    private fun primaryButton(textValue: String, action: () -> Unit): Button = Button(this).apply {
        text = textValue
        textSize = 16f
        setTextColor(0xFFFFFFFF.toInt())
        background = rounded(0xFF2563EB.toInt(), 20f, 0xFF60A5FA.toInt())
        setPadding(dp(8), dp(10), dp(8), dp(10))
        setOnClickListener { action() }
    }

    private fun secondaryButton(textValue: String, action: () -> Unit): Button = Button(this).apply {
        text = textValue
        textSize = 15f
        setTextColor(0xFFFFFFFF.toInt())
        background = rounded(0xFF1F2937.toInt(), 20f, 0xFF4B5563.toInt())
        setPadding(dp(8), dp(9), dp(8), dp(9))
        setOnClickListener { action() }
    }

    private fun rounded(color: Int, radius: Float, stroke: Int): GradientDrawable = GradientDrawable().apply {
        cornerRadius = radius
        setColor(color)
        setStroke(dp(1), stroke)
    }

    private fun updatePermissionCards() {
        overlayPermissionCard.text = if (Settings.canDrawOverlays(this)) "חלון צף: מאושר ✅" else "חלון צף: חסר ⚠️"
        capturePermissionCard.text = "צילום מסך: מבקשים באוטומטי"
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(ErrorReporter.ACTION_ERROR)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) registerReceiver(errorReceiver, filter, RECEIVER_NOT_EXPORTED)
        else registerReceiver(errorReceiver, filter)
    }

    override fun onStop() {
        runCatching { unregisterReceiver(errorReceiver) }
        super.onStop()
    }


    private fun openCalibrationMode() {
        if (!ensureOverlayPermission()) return
        statusText.text = "מצב כיול נפתח. גרור את המסגרות למיקום היד והשולחן ואז שמור."
        runCatching { startService(Intent(this, CalibrationOverlayService::class.java)) }
            .onFailure {
                ErrorReporter.report(this, "כיול מיקומים", it, "לא הצלחתי לפתוח כיול מיקומים")
                statusText.text = "בעיה בפתיחת כיול מיקומים: ${it.message ?: "לא ידוע"}"
            }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 4401)
        }
    }

    private fun ensureOverlayPermission(): Boolean {
        if (!Settings.canDrawOverlays(this)) {
            statusText.text = "חסרה הרשאת חלון צף. תאשר הצגה מעל אפליקציות ואז תחזור."
            Toast.makeText(this, "צריך לאשר הצגה מעל אפליקציות", Toast.LENGTH_LONG).show()
            openOverlayPermissionSettings()
            return false
        }
        return true
    }

    private fun openOverlayPermissionSettings() {
        runCatching { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
            .onFailure { ErrorReporter.report(this, "הרשאת חלון צף", it, "לא הצלחתי לפתוח מסך הרשאות") }
    }

    private fun openOverlayOnly() {
        if (!ensureOverlayPermission()) return
        statusText.text = "חלון צף נפתח. אפשר לבחור קלפים ידנית ולבדוק את המד."
        runCatching { startService(Intent(this, FloatingOverlayService::class.java)) }
            .onFailure {
                ErrorReporter.report(this, "פתיחת חלון צף", it, "לא הצלחתי לפתוח חלון צף")
                statusText.text = "בעיה בפתיחת חלון צף: ${it.message ?: "לא ידוע"}"
            }
    }

    private fun startAutoMode() {
        if (!ensureOverlayPermission()) return
        statusText.text = "מבקש הרשאת צילום מסך. תאשר כדי שזיהוי אוטומטי יעבוד."
        runCatching { startService(Intent(this, FloatingOverlayService::class.java)) }
            .onFailure { ErrorReporter.report(this, "פתיחת חלון צף", it, "לא הצלחתי לפתוח חלון צף") }
        runCatching {
            val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(mgr.createScreenCaptureIntent(), captureRequestCode)
        }.onFailure {
            ErrorReporter.report(this, "הרשאת צילום מסך", it, "לא הצלחתי לפתוח בקשת צילום מסך")
            statusText.text = "בעיה בבקשת צילום מסך: ${it.message ?: "לא ידוע"}"
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequestCode && resultCode == Activity.RESULT_OK && data != null) {
            statusText.text = "זיהוי אוטומטי פעיל. פתח סרטון ובדוק את המד."
            val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(ScreenCaptureService.EXTRA_DATA, data)
            }
            runCatching { startForegroundService(serviceIntent) }
                .onFailure {
                    ErrorReporter.report(this, "הפעלת זיהוי", it, "לא הצלחתי להפעיל זיהוי אוטומטי")
                    statusText.text = "שגיאה בהפעלת זיהוי: ${it.message ?: "לא ידוע"}"
                }
        } else if (requestCode == captureRequestCode) {
            statusText.text = "צילום מסך לא אושר. אפשר להשתמש במצב ידני."
            Toast.makeText(this, "צילום מסך לא אושר", Toast.LENGTH_LONG).show()
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
