package com.tomer.pokertrainer.poker

import com.tomer.pokertrainer.model.Card

class PokerAnalyzer {
    private val evaluator = PokerHandEvaluator()
    private val simulator = MonteCarloSimulator(evaluator)
    private val outsCalculator = OutsCalculator(evaluator)
    private val improvementCalculator = ImprovementCalculator(evaluator)
    private val explanation = TrainingExplanationEngine()

    fun analyze(hero: List<Card>, board: List<Card>, opponents: Int): HandResult {
        val safeHero = hero.distinct().take(2)
        val safeBoard = normalizeBoard(board.filterNot { it in safeHero })
        if (safeHero.size != 2) {
            return HandResult("אין 2 קלפים", 0, 0, 0, 0, 0, emptyList(), "בחר 2 קלפים", "חסרים קלפים לחישוב")
        }

        val eval = evaluator.evaluate(safeHero + safeBoard)
        val win = simulator.estimateWinPercent(safeHero, safeBoard, opponents)
        val improveNext = improvementCalculator.nextCardImprovePercent(safeHero, safeBoard)
        val improveRiver = improvementCalculator.toRiverImprovePercent(safeHero, safeBoard)
        val (draws, outs) = outsCalculator.drawsAndOuts(safeHero, safeBoard)
        val nowScore = if (safeBoard.isEmpty()) preflopPotential(safeHero) else contextualMadeHandScore(eval.second, safeHero, safeBoard)
        val potential = futurePotentialScore(safeHero, safeBoard, outs, improveNext, improveRiver, draws)

        val smartScore = when (safeBoard.size) {
            0 -> (nowScore * 0.50 + win * 0.50).toInt()
            3 -> (nowScore * 0.45 + win * 0.40 + potential * 0.15).toInt()
            4 -> (nowScore * 0.50 + win * 0.42 + potential * 0.08).toInt()
            5 -> (nowScore * 0.72 + win * 0.28).toInt()
            else -> (nowScore * 0.50 + win * 0.50).toInt()
        }.coerceIn(0, 100)

        val (action, text) = explanation.build(eval.second, win, improveNext, improveRiver, outs, draws, safeHero, safeBoard)
        return HandResult(eval.second, smartScore, win, improveNext, improveRiver, outs, draws, action, text)
    }

    private fun normalizeBoard(board: List<Card>): List<Card> {
        val unique = board.distinct().take(5)
        return when (unique.size) {
            0, 3, 4, 5 -> unique
            1, 2 -> emptyList()
            else -> unique.take(5)
        }
    }

    private fun contextualMadeHandScore(category: String, hero: List<Card>, board: List<Card>): Int {
        val cards = hero + board
        val counts = cards.groupingBy { it.rank.value }.eachCount()
        val boardRanks = board.map { it.rank.value }
        val heroRanks = hero.map { it.rank.value }
        val topBoard = boardRanks.maxOrNull() ?: 0

        return when {
            category.contains("Royal") -> 100
            category.contains("Straight Flush") -> 98
            category.contains("Four") -> 95
            category.contains("Full House") -> 89
            category.contains("Flush") -> flushScore(hero, board)
            category.contains("Straight") -> 72
            category.contains("Three") -> tripsScore(hero, board, counts)
            category.contains("Two Pair") -> twoPairScore(hero, board, counts)
            category.contains("One Pair") -> pairScore(hero, board, counts, topBoard)
            else -> highCardScore(heroRanks, boardRanks)
        }.coerceIn(1, 100)
    }

    private fun pairScore(hero: List<Card>, board: List<Card>, counts: Map<Int, Int>, topBoard: Int): Int {
        val pairRanks = counts.filterValues { it >= 2 }.keys.sortedDescending()
        val pair = pairRanks.firstOrNull() ?: return 20
        val pocketPair = hero.size == 2 && hero[0].rank == hero[1].rank
        val heroUsesPair = hero.any { it.rank.value == pair }
        val kicker = hero.map { it.rank.value }.filter { it != pair }.maxOrNull() ?: 0
        val boardPairedOnly = !heroUsesPair && board.count { it.rank.value == pair } >= 2

        return when {
            pocketPair && pair > topBoard -> 76   // overpair
            pocketPair && pair == topBoard -> 66
            pocketPair -> 50 + (pair - 8) * 2
            boardPairedOnly -> 25 + highCardScore(hero.map { it.rank.value }, board.map { it.rank.value }) / 4
            heroUsesPair && pair == topBoard -> 55 + kickerBonus(kicker)  // top pair
            heroUsesPair && pair >= 10 -> 48 + kickerBonus(kicker)
            heroUsesPair -> 36 + kickerBonus(kicker)
            else -> 28
        }
    }

    private fun twoPairScore(hero: List<Card>, board: List<Card>, counts: Map<Int, Int>): Int {
        val pairRanks = counts.filterValues { it >= 2 }.keys.sortedDescending().take(2)
        val heroTouch = hero.count { h -> pairRanks.contains(h.rank.value) }
        val boardHasTwoPair = pairRanks.all { r -> board.count { it.rank.value == r } >= 2 }
        return when {
            heroTouch == 2 -> 66 + pairRanks.first() / 2
            heroTouch == 1 -> 58 + pairRanks.first() / 3
            boardHasTwoPair -> 43 + hero.maxOf { it.rank.value } / 3
            else -> 52
        }
    }

    private fun tripsScore(hero: List<Card>, board: List<Card>, counts: Map<Int, Int>): Int {
        val trip = counts.filterValues { it >= 3 }.keys.maxOrNull() ?: return 60
        val heroCount = hero.count { it.rank.value == trip }
        return when (heroCount) {
            2 -> 82 // set from pocket pair
            1 -> 74 // trips with one hero card
            else -> 54 // trips on board
        }
    }

    private fun flushScore(hero: List<Card>, board: List<Card>): Int {
        val flushSuit = (hero + board).groupBy { it.suit }.filterValues { it.size >= 5 }.keys.firstOrNull()
        val heroFlushRanks = hero.filter { it.suit == flushSuit }.map { it.rank.value }
        val high = heroFlushRanks.maxOrNull() ?: 0
        return when {
            high == 14 -> 86
            high >= 12 -> 81
            high >= 10 -> 76
            heroFlushRanks.isNotEmpty() -> 70
            else -> 60 // flush only on board
        }
    }

    private fun highCardScore(heroRanks: List<Int>, boardRanks: List<Int>): Int {
        val high = heroRanks.maxOrNull() ?: 0
        val second = heroRanks.minOrNull() ?: 0
        val overcards = if (boardRanks.isEmpty()) 0 else heroRanks.count { it > (boardRanks.maxOrNull() ?: 0) }
        return (high * 2 + second + overcards * 7 - if (second <= 5) 4 else 0).coerceIn(8, 48)
    }

    private fun kickerBonus(kicker: Int): Int = when {
        kicker == 14 -> 12
        kicker >= 13 -> 10
        kicker >= 12 -> 8
        kicker >= 10 -> 5
        kicker >= 7 -> 2
        else -> -3
    }

    private fun futurePotentialScore(hero: List<Card>, board: List<Card>, outs: Int, next: Int, river: Int, draws: List<String>): Int {
        if (hero.size != 2 || board.size >= 5) return 0
        var score = outs * 4 + next / 2 + river / 3
        if (draws.any { it.contains("Flush") }) score += 14
        if (draws.any { it.contains("Straight") }) score += 12
        if (draws.any { it.contains("Overcards") }) score += 6
        return score.coerceIn(0, 100)
    }

    private fun preflopPotential(hero: List<Card>): Int {
        if (hero.size != 2) return 0
        val a = hero[0]
        val b = hero[1]
        val high = maxOf(a.rank.value, b.rank.value)
        val low = minOf(a.rank.value, b.rank.value)
        val suited = a.suit == b.suit
        val gap = kotlin.math.abs(high - low)

        if (a.rank == b.rank) return when (high) {
            14 -> 99; 13 -> 96; 12 -> 93; 11 -> 89; 10 -> 85; 9 -> 80; 8 -> 75; 7 -> 70; 6 -> 66; 5 -> 62; 4 -> 59; 3 -> 56; else -> 53
        }

        var score = when (high) {
            14 -> 48; 13 -> 42; 12 -> 38; 11 -> 34; 10 -> 30; else -> high * 2
        } + low
        if (suited) score += 8
        score += when (gap) { 1 -> 9; 2 -> 6; 3 -> 3; 4 -> 1; else -> -4 }
        if (high == 14 && low >= 10) score += 10
        if (high >= 13 && low >= 10) score += 6
        if (low <= 5 && gap >= 4) score -= 10
        if (high <= 9 && suited && gap <= 2) score += 5 // suited connectors
        return score.coerceIn(4, 92)
    }
}
