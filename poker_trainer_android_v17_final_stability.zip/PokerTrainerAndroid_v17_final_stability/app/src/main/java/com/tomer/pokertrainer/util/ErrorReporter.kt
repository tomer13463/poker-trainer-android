package com.tomer.pokertrainer.util

import android.content.Context
import android.content.Intent
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ErrorReporter {
    const val ACTION_ERROR = "com.tomer.pokertrainer.ACTION_ERROR"
    const val EXTRA_AREA = "area"
    const val EXTRA_MESSAGE = "message"
    const val EXTRA_DETAILS = "details"
    private const val PREFS = "poker_trainer_errors"
    private const val KEY_LAST_ERROR = "last_error"
    private const val MAX_LOG_CHARS = 6000

    fun report(context: Context, area: String, throwable: Throwable? = null, message: String? = null) {
        val userMessage = message ?: throwable?.message ?: "שגיאה לא ידועה"
        val details = buildString {
            append(now()).append(" | ").append(area).append(" | ").append(userMessage)
            throwable?.let {
                append("\n").append(it::class.java.simpleName).append(": ").append(it.message ?: "")
                append("\n").append(it.stackTraceToString())
            }
        }.take(MAX_LOG_CHARS)

        Log.e("PokerTrainer", "$area: $userMessage", throwable)
        runCatching {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_LAST_ERROR, details)
                .apply()
        }
        runCatching {
            val dir = File(context.getExternalFilesDir(null), "logs")
            dir.mkdirs()
            File(dir, "last_error.txt").writeText(details)
        }
        runCatching {
            context.sendBroadcast(Intent(ACTION_ERROR).apply {
                putExtra(EXTRA_AREA, area)
                putExtra(EXTRA_MESSAGE, userMessage)
                putExtra(EXTRA_DETAILS, details)
            })
        }
    }

    fun lastError(context: Context): String {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_LAST_ERROR, "")
            .orEmpty()
    }

    fun clear(context: Context) {
        runCatching {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .remove(KEY_LAST_ERROR)
                .apply()
        }
        runCatching { File(context.getExternalFilesDir(null), "logs/last_error.txt").delete() }
    }

    private fun now(): String = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
}
