package com.tomer.pokertrainer.poker

import com.tomer.pokertrainer.model.Card
import com.tomer.pokertrainer.model.Rank
import com.tomer.pokertrainer.model.Suit
import kotlin.math.roundToInt

class ImprovementCalculator(private val evaluator: PokerHandEvaluator = PokerHandEvaluator()) {
    private val fullDeck = Rank.entries.flatMap { r -> Suit.entries.map { s -> Card(r, s) } }

    fun nextCardImprovePercent(hero: List<Card>, board: List<Card>): Int {
        if (hero.size != 2 || board.size >= 5) return 0
        val used = (hero + board).toSet()
        val deck = fullDeck.filterNot { it in used }
        val current = evaluator.evaluate(hero + board).first
        val improving = deck.count { card -> evaluator.evaluate(hero + board + card).first > current }
        return ((improving.toDouble() / deck.size.toDouble()) * 100).roundToInt().coerceIn(0, 100)
    }

    fun toRiverImprovePercent(hero: List<Card>, board: List<Card>): Int {
        if (hero.size != 2 || board.size >= 5) return 0
        val used = (hero + board).toSet()
        val deck = fullDeck.filterNot { it in used }
        val current = evaluator.evaluate(hero + board).first
        val needed = 5 - board.size

        if (needed <= 1) return nextCardImprovePercent(hero, board)

        var total = 0
        var improving = 0

        // Preflop has 5 unknown board cards, exhaustive is too expensive.
        // Use deterministic sample that is stable enough for the overlay.
        if (board.isEmpty()) {
            val runs = 4000
            val rng = kotlin.random.Random(4242 + hero.sumOf { it.rank.value })
            repeat(runs) {
                val sample = deck.shuffled(rng).take(5)
                total++
                if (evaluator.evaluate(hero + sample).first > current) improving++
            }
        } else {
            for (i in deck.indices) {
                for (j in i + 1 until deck.size) {
                    total++
                    val finalBoard = board + deck[i] + deck[j]
                    if (evaluator.evaluate(hero + finalBoard).first > current) improving++
                }
            }
        }

        if (total == 0) return 0
        return ((improving.toDouble() / total.toDouble()) * 100).roundToInt().coerceIn(0, 100)
    }
}
