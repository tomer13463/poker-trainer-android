package com.tomer.pokertrainer.poker

import com.tomer.pokertrainer.model.Card
import com.tomer.pokertrainer.model.Rank
import com.tomer.pokertrainer.model.Suit
import kotlin.random.Random
import kotlin.math.roundToInt

class MonteCarloSimulator(private val evaluator: PokerHandEvaluator = PokerHandEvaluator()) {
    private val fullDeck = Rank.entries.flatMap { r -> Suit.entries.map { s -> Card(r, s) } }

    fun estimateWinPercent(hero: List<Card>, board: List<Card>, opponents: Int, runs: Int = adaptiveRuns(board.size, opponents)): Int {
        if (hero.size != 2) return 0
        if (board.size > 5) return 0
        if ((hero + board).distinct().size != hero.size + board.size) return 0

        val oppCount = opponents.coerceIn(1, 8)
        val used = (hero + board).toSet()
        val available = fullDeck.filterNot { it in used }
        if (available.size < oppCount * 2 + (5 - board.size)) return 0

        // River + one opponent can be exact and very stable.
        if (board.size == 5 && oppCount == 1) {
            var equity = 0.0
            var total = 0
            val heroScore = evaluator.evaluate(hero + board).first
            for (i in available.indices) {
                for (j in i + 1 until available.size) {
                    total++
                    val oppScore = evaluator.evaluate(listOf(available[i], available[j]) + board).first
                    equity += when {
                        heroScore > oppScore -> 1.0
                        heroScore == oppScore -> 0.5
                        else -> 0.0
                    }
                }
            }
            return ((equity / total.toDouble()) * 100.0).roundPercent()
        }

        var equity = 0.0
        val rng = Random(17 + board.size * 31 + oppCount * 101 + hero.sumOf { it.rank.value })

        repeat(runs) {
            val deck = available.shuffled(rng).toMutableList()
            val oppHands = ArrayList<List<Card>>(oppCount)
            repeat(oppCount) {
                oppHands.add(listOf(deck.removeAt(deck.lastIndex), deck.removeAt(deck.lastIndex)))
            }

            val completedBoard = board.toMutableList()
            while (completedBoard.size < 5) completedBoard.add(deck.removeAt(deck.lastIndex))

            val heroScore = evaluator.evaluate(hero + completedBoard).first
            val oppScores = oppHands.map { evaluator.evaluate(it + completedBoard).first }
            val bestScore = (oppScores + heroScore).maxOrNull() ?: heroScore

            if (heroScore == bestScore) {
                val tiedWinners = 1 + oppScores.count { it == bestScore }
                equity += 1.0 / tiedWinners.toDouble()
            }
        }

        return ((equity / runs.toDouble()) * 100.0).roundPercent()
    }

    companion object {
        fun adaptiveRuns(boardSize: Int, opponents: Int): Int {
            val opp = opponents.coerceIn(1, 8)
            val base = when (boardSize) {
                0 -> 4500
                3 -> 6500
                4 -> 7500
                5 -> 9000
                else -> 5000
            }
            return (base + opp * 400).coerceAtMost(12000)
        }

        private fun Double.roundPercent(): Int = this.roundToInt().coerceIn(0, 100)
    }
}
