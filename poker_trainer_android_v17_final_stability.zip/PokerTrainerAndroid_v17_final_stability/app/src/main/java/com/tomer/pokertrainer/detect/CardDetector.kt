package com.tomer.pokertrainer.detect

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.content.Context
import com.tomer.pokertrainer.model.Card
import com.tomer.pokertrainer.model.Rank
import com.tomer.pokertrainer.model.Suit
import com.tomer.pokertrainer.util.CalibrationStore
import com.tomer.pokertrainer.util.RectRel
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * זיהוי אוטומטי בסיסי לפי אזורי קלפים קבועים במסך.
 *
 * v6:
 * - תומך בשני עיצובים:
 *   1. שולחן ירוק בסגנון ClubGG / GG
 *   2. שולחן אדום בסגנון PokerFace / וידאו צ'אט
 * - בוחר לבד את הפרופיל עם הכי הרבה קלפים אמינים.
 * - עדיין MVP: אם הזיהוי טועה מתקנים ידנית מהחלון הצף.
 * - משתמש באחוזי מסך כדי לעבוד גם במסך מלא וגם ברוב יחסי הגודל.
 */
class CardDetector {

    private data class TableProfile(
        val name: String,
        val heroRects: List<RectFRel>,
        val boardRects: List<RectFRel>
    )

    private data class RectFRel(val l: Float, val t: Float, val r: Float, val b: Float)

    private data class ProfileResult(
        val profileName: String,
        val hero: List<DetectedCard>,
        val board: List<DetectedCard>,
        val score: Float,
        val debug: String
    )

    fun detect(frame: Bitmap, forcedProfile: String = "auto", context: Context? = null): CardDetectionResult {
        val w = frame.width
        val h = frame.height

        val profiles = mutableListOf(
            // דוגמת השולחן הירוק ששלחת: הקלפים שלך למטה שמאל/מרכז, הלוח באמצע.
            TableProfile(
                name = "green_table",
                heroRects = listOf(
                    RectFRel(0.055f, 0.720f, 0.140f, 0.805f),
                    RectFRel(0.120f, 0.720f, 0.255f, 0.805f)
                ),
                boardRects = listOf(
                    RectFRel(0.195f, 0.452f, 0.310f, 0.528f),
                    RectFRel(0.315f, 0.452f, 0.430f, 0.528f),
                    RectFRel(0.435f, 0.452f, 0.550f, 0.528f),
                    RectFRel(0.555f, 0.452f, 0.670f, 0.528f),
                    RectFRel(0.675f, 0.452f, 0.790f, 0.528f)
                )
            ),
            // דוגמת PokerFace / שולחן אדום: הקלפים שלך למטה ימין יחסית, הלוח באמצע.
            TableProfile(
                name = "pokerface_red_table",
                heroRects = listOf(
                    RectFRel(0.585f, 0.835f, 0.745f, 0.945f),
                    RectFRel(0.700f, 0.830f, 0.895f, 0.945f)
                ),
                boardRects = listOf(
                    RectFRel(0.170f, 0.400f, 0.315f, 0.505f),
                    RectFRel(0.300f, 0.400f, 0.445f, 0.505f),
                    RectFRel(0.430f, 0.400f, 0.575f, 0.505f),
                    RectFRel(0.560f, 0.400f, 0.705f, 0.505f),
                    RectFRel(0.690f, 0.400f, 0.835f, 0.505f)
                )
            )
        )
        val customProfile = context?.let { buildCustomProfile(it) }
        if (customProfile != null) profiles.add(customProfile)

        val candidates = if (forcedProfile == "auto") profiles else profiles.filter { it.name == forcedProfile }.ifEmpty { profiles }
        val results = candidates.map { profile -> analyzeProfile(frame, w, h, profile) }
        val best = results.maxByOrNull { it.score } ?: results.first()

        val heroConf = best.hero.joinToString(" ") { "${it.card} ${"%.0f".format(it.confidence * 100)}%" }
        val boardConf = best.board.joinToString(" ") { "${it.card} ${"%.0f".format(it.confidence * 100)}%" }
        val debug = "profile=${best.profileName} mode=$forcedProfile size=${w}x${h} h=${best.hero.size} b=${best.board.size}"
        return CardDetectionResult(best.hero, best.board, debug, heroConf, boardConf)
    }


    private fun buildCustomProfile(context: Context): TableProfile? {
        if (!CalibrationStore.isEnabled(context)) return null
        val hero = CalibrationStore.hero(context) ?: return null
        val board = CalibrationStore.board(context) ?: return null
        return TableProfile(
            name = "custom",
            heroRects = splitHero(hero),
            boardRects = splitBoard(board)
        )
    }

    private fun splitHero(rect: RectRel): List<RectFRel> {
        val width = rect.r - rect.l
        val gap = width * 0.04f
        val cardWidth = (width - gap) / 2f
        return listOf(
            RectFRel(rect.l, rect.t, rect.l + cardWidth, rect.b),
            RectFRel(rect.l + cardWidth + gap, rect.t, rect.r, rect.b)
        )
    }

    private fun splitBoard(rect: RectRel): List<RectFRel> {
        val width = rect.r - rect.l
        val gap = width * 0.02f
        val cardWidth = (width - gap * 4f) / 5f
        return (0 until 5).map { idx ->
            val left = rect.l + idx * (cardWidth + gap)
            RectFRel(left, rect.t, left + cardWidth, rect.b)
        }
    }

    private fun analyzeProfile(src: Bitmap, w: Int, h: Int, profile: TableProfile): ProfileResult {
        val hero = profile.heroRects.mapNotNull { detectCard(src, rel(w, h, it), "hero") }.filter { it.confidence >= 0.42f }
        val board = profile.boardRects.mapNotNull { detectCard(src, rel(w, h, it), "board") }.filter { it.confidence >= 0.42f }

        // ניקוד בחירה: שני קלפים שלך חשובים יותר מהלוח. אם אין שני קלפים – הפרופיל פחות טוב.
        val heroScore = hero.sumOf { it.confidence.toDouble() }.toFloat() * 3.0f
        val boardScore = board.sumOf { it.confidence.toDouble() }.toFloat()
        val completeHeroBonus = if (hero.size >= 2) 4.0f else 0.0f
        val score = heroScore + boardScore + completeHeroBonus

        val uniqueHero = hero.distinctBy { it.card }.take(2)
        val uniqueBoard = board.distinctBy { it.card }.filterNot { b -> uniqueHero.any { it.card == b.card } }.take(5)
        return ProfileResult(
            profile.name,
            uniqueHero,
            uniqueBoard,
            score,
            "${profile.name}: score=${"%.2f".format(score)} h=${uniqueHero.size} b=${uniqueBoard.size}"
        )
    }

    private fun rel(w: Int, h: Int, rr: RectFRel): Rect = Rect(
        (w * rr.l).toInt(), (h * rr.t).toInt(), (w * rr.r).toInt(), (h * rr.b).toInt()
    )

    private fun detectCard(src: Bitmap, rect: Rect, source: String): DetectedCard? {
        val safe = Rect(
            rect.left.coerceIn(0, src.width - 1),
            rect.top.coerceIn(0, src.height - 1),
            rect.right.coerceIn(1, src.width),
            rect.bottom.coerceIn(1, src.height)
        )
        if (safe.width() < 18 || safe.height() < 18) return null
        val crop = Bitmap.createBitmap(src, safe.left, safe.top, safe.width(), safe.height())

        // לבדוק שבאמת יש קלף: הרבה לבן/אפור בהיר באזור.
        val whiteRatio = brightRatio(crop)
        if (whiteRatio < 0.08f) {
            crop.recycle()
            return null
        }

        val cornerW = max(16, (crop.width * 0.52f).toInt()).coerceAtMost(crop.width)
        val cornerH = max(20, (crop.height * 0.66f).toInt()).coerceAtMost(crop.height)
        val corner = Bitmap.createBitmap(crop, 0, 0, cornerW, cornerH)
        val suit = detectSuitByColorAndShape(corner)
        val rank = detectRankByTemplate(corner, suit)
        val rankConfidence = rankConfidence(corner, rank, suit)
        val conf = (whiteRatio * 0.40f + rankConfidence * 0.45f + 0.18f).coerceIn(0.25f, 0.98f)
        crop.recycle()
        corner.recycle()
        return DetectedCard(Card(rank, suit), conf, source)
    }

    private fun brightRatio(bmp: Bitmap): Float {
        var bright = 0
        var all = 0
        val stepX = max(1, bmp.width / 42)
        val stepY = max(1, bmp.height / 42)
        var y = 0
        while (y < bmp.height) {
            var x = 0
            while (x < bmp.width) {
                val c = bmp.getPixel(x, y)
                val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
                // קלפים לבנים יכולים להיות מעט אפורים/מוצלים בסרטון.
                if (r + g + b > 485 && max(r, max(g, b)) > 165) bright++
                all++
                x += stepX
            }
            y += stepY
        }
        return bright.toFloat() / max(1, all)
    }

    private fun detectSuitByColorAndShape(corner: Bitmap): Suit {
        var red = 0
        var black = 0
        var y = 0
        while (y < corner.height) {
            var x = 0
            while (x < corner.width) {
                val c = corner.getPixel(x, y)
                val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
                if (r > 115 && r > g * 1.25 && r > b * 1.25) red++
                if (r < 95 && g < 95 && b < 95) black++
                x += 2
            }
            y += 2
        }
        if (red > black) {
            // אדום: לב נוטה להיות מלא/רחב יותר בתחתית הסמל, יהלום יותר סימטרי.
            return if (lowerInkRatio(corner, true) > 0.50f) Suit.HEARTS else Suit.DIAMONDS
        }
        // שחור: עלה נוטה להיות עם "גבעול" ויותר דיו למטה, תלתן עגול יותר למעלה.
        return if (lowerInkRatio(corner, false) > 0.54f) Suit.SPADES else Suit.CLUBS
    }

    private fun lowerInkRatio(bmp: Bitmap, redMode: Boolean): Float {
        var lower = 0; var total = 0
        val mid = bmp.height / 2
        for (y in 0 until bmp.height step 2) {
            for (x in 0 until bmp.width step 2) {
                val c = bmp.getPixel(x, y)
                val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
                val ink = if (redMode) r > 115 && r > g * 1.20 && r > b * 1.20 else r < 105 && g < 105 && b < 105
                if (ink) { total++; if (y > mid) lower++ }
            }
        }
        return lower.toFloat() / max(1, total)
    }

    private fun detectRankByTemplate(corner: Bitmap, suit: Suit): Rank {
        val redMode = suit == Suit.HEARTS || suit == Suit.DIAMONDS
        val ink = toInkBitmap(corner, redMode)
        var bestRank = Rank.ACE
        var bestScore = Float.MAX_VALUE
        for (rank in Rank.entries) {
            val tpl = rankTemplate(ink.width, ink.height, rank.label)
            val score = diff(ink, tpl)
            if (score < bestScore) { bestScore = score; bestRank = rank }
            tpl.recycle()
        }
        ink.recycle()
        return bestRank
    }

    private fun toInkBitmap(src: Bitmap, redMode: Boolean): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        for (y in 0 until src.height) {
            for (x in 0 until src.width) {
                val c = src.getPixel(x, y)
                val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
                val isInk = if (redMode) r > 110 && r > g * 1.18 && r > b * 1.18 else r < 125 && g < 125 && b < 125
                out.setPixel(x, y, if (isInk) Color.BLACK else Color.WHITE)
            }
        }
        return out
    }

    private fun rankTemplate(w: Int, h: Int, label: String): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(Color.WHITE)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textSize = h * if (label == "10") 0.32f else 0.46f
        }
        canvas.drawText(label, w * 0.07f, h * 0.36f, p)
        return bmp
    }

    private fun rankConfidence(corner: Bitmap, rank: Rank, suit: Suit): Float {
        val redMode = suit == Suit.HEARTS || suit == Suit.DIAMONDS
        val ink = toInkBitmap(corner, redMode)
        val tpl = rankTemplate(ink.width, ink.height, rank.label)
        val d = diff(ink, tpl)
        ink.recycle(); tpl.recycle()
        return (1.0f - d).coerceIn(0.0f, 1.0f)
    }

    private fun diff(a: Bitmap, b: Bitmap): Float {
        val stepX = max(1, a.width / 30)
        val stepY = max(1, a.height / 30)
        var err = 0f; var n = 0
        for (y in 0 until min(a.height, b.height) step stepY) {
            for (x in 0 until min(a.width, b.width) step stepX) {
                val av = if (Color.red(a.getPixel(x, y)) < 128) 1 else 0
                val bv = if (Color.red(b.getPixel(x, y)) < 128) 1 else 0
                err += abs(av - bv).toFloat()
                n++
            }
        }
        return err / max(1, n)
    }
}
