package com.tomer.pokertrainer.util

import android.content.Context

data class RectRel(val l: Float, val t: Float, val r: Float, val b: Float) {
    fun sanitize(): RectRel {
        val sl = l.coerceIn(0f, 0.98f)
        val st = t.coerceIn(0f, 0.98f)
        val sr = r.coerceIn(sl + 0.01f, 1f)
        val sb = b.coerceIn(st + 0.01f, 1f)
        return RectRel(sl, st, sr, sb)
    }
}

object CalibrationStore {
    private const val PREFS = "poker_trainer_calibration"
    private const val KEY_ENABLED = "custom_enabled"
    private const val KEY_HERO = "hero_rect"
    private const val KEY_BOARD = "board_rect"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun save(context: Context, hero: RectRel, board: RectRel) {
        prefs(context).edit()
            .putBoolean(KEY_ENABLED, true)
            .putString(KEY_HERO, encode(hero.sanitize()))
            .putString(KEY_BOARD, encode(board.sanitize()))
            .apply()
    }

    fun clear(context: Context) {
        prefs(context).edit().clear().apply()
    }

    fun isEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_ENABLED, false)

    fun hero(context: Context): RectRel? = decode(prefs(context).getString(KEY_HERO, null))
    fun board(context: Context): RectRel? = decode(prefs(context).getString(KEY_BOARD, null))

    private fun encode(rect: RectRel): String = "${rect.l},${rect.t},${rect.r},${rect.b}"

    private fun decode(raw: String?): RectRel? {
        if (raw.isNullOrBlank()) return null
        val parts = raw.split(",")
        if (parts.size != 4) return null
        val values = parts.mapNotNull { it.toFloatOrNull() }
        if (values.size != 4) return null
        return RectRel(values[0], values[1], values[2], values[3]).sanitize()
    }
}
