package com.tomer.pokertrainer.poker

import com.tomer.pokertrainer.model.Card

class TrainingExplanationEngine {
    fun build(
        category: String,
        win: Int,
        improveNext: Int,
        improveRiver: Int,
        outs: Int,
        draws: List<String>,
        hero: List<Card>,
        board: List<Card>
    ): Pair<String, String> {
        val action = when {
            win >= 70 -> "יד חזקה - אפשר לחשוב אגרסיבי"
            win >= 45 -> "בינוני - אפשר לשלם בזהירות"
            win >= 28 -> "חלש/גבולי - להיזהר"
            else -> "חלש - לרוב עדיף לקפל"
        }
        val stage = when (board.size) { 0 -> "לפני פלופ"; 3 -> "פלופ"; 4 -> "טרן"; 5 -> "ריבר"; else -> "יד חלקית" }
        val drawText = if (draws.isEmpty()) "אין Draw חזק" else draws.joinToString(" / ")
        val futureText = if (board.size < 5) "שיפור קלף הבא: $improveNext%, עד הריבר: $improveRiver%." else "אין עוד קלפים להיפתח."
        val explanation = "מצב: $stage. יד: $category. $drawText. Outs: $outs. $futureText"
        return action to explanation
    }
}
