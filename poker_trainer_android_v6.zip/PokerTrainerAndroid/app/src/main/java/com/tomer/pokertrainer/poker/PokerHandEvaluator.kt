package com.tomer.pokertrainer.poker

import com.tomer.pokertrainer.model.Card
import com.tomer.pokertrainer.model.Rank

class PokerHandEvaluator {
    fun evaluate(cards: List<Card>): Pair<Int, String> {
        if (cards.isEmpty()) return 0 to "אין קלפים"
        val byRank = cards.groupBy { it.rank }.mapValues { it.value.size }
        val bySuit = cards.groupBy { it.suit }.mapValues { it.value.size }
        val flushSuit = bySuit.entries.firstOrNull { it.value >= 5 }?.key
        val ranks = cards.map { it.rank.value }.distinct().sortedDescending()
        val straightHigh = straightHigh(ranks)
        val flushCards = if (flushSuit != null) cards.filter { it.suit == flushSuit } else emptyList()
        val straightFlush = if (flushCards.size >= 5) straightHigh(flushCards.map { it.rank.value }.distinct().sortedDescending()) else null
        if (straightFlush != null && straightFlush == 14) return 900 to "Royal Flush"
        if (straightFlush != null) return 850 + straightFlush to "Straight Flush"
        val counts = byRank.entries.sortedWith(compareByDescending<Map.Entry<Rank, Int>> { it.value }.thenByDescending { it.key.value })
        val four = counts.firstOrNull { it.value == 4 }
        if (four != null) return 800 + four.key.value to "Four of a Kind"
        val trips = counts.filter { it.value >= 3 }
        val pairs = counts.filter { it.value >= 2 }
        if (trips.isNotEmpty() && (pairs.size >= 2 || trips.size >= 2)) return 700 + trips.first().key.value to "Full House"
        if (flushSuit != null) return 600 + flushCards.maxOf { it.rank.value } to "Flush"
        if (straightHigh != null) return 500 + straightHigh to "Straight"
        if (trips.isNotEmpty()) return 400 + trips.first().key.value to "Three of a Kind"
        if (pairs.size >= 2) return 300 + pairs.take(2).sumOf { it.key.value } to "Two Pair"
        if (pairs.size == 1) return 200 + pairs.first().key.value to "One Pair"
        return ranks.take(5).sum() to "High Card"
    }

    private fun straightHigh(ranks: List<Int>): Int? {
        val set = ranks.toMutableSet()
        if (14 in set) set.add(1)
        for (high in 14 downTo 5) {
            if ((0..4).all { (high - it) in set }) return high
        }
        return null
    }
}
