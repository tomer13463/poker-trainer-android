package com.tomer.pokertrainer.detect

import com.tomer.pokertrainer.model.Card

data class DetectedCard(
    val card: Card,
    val confidence: Float,
    val source: String
)

data class CardDetectionResult(
    val heroCards: List<DetectedCard>,
    val boardCards: List<DetectedCard>,
    val debugText: String,
    val heroConfidenceText: String = "",
    val boardConfidenceText: String = ""
)
