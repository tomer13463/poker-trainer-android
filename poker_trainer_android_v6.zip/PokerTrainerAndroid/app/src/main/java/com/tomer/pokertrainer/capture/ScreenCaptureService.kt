package com.tomer.pokertrainer.capture

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.tomer.pokertrainer.detect.CardDetector
import java.io.File
import java.io.FileOutputStream

class ScreenCaptureService : Service() {
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private val detector = CardDetector()
    private val handler = Handler(Looper.getMainLooper())
    private var lastAnalyzeAt = 0L
    private var forcedProfile: String = "auto"
    private var saveNextFrame = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                sendBroadcast(Intent(ACTION_STATUS).apply { putExtra(EXTRA_STATUS, "זיהוי נעצר") })
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_SET_PROFILE -> {
                forcedProfile = intent.getStringExtra(EXTRA_PROFILE) ?: "auto"
                return START_STICKY
            }
            ACTION_SAVE_NEXT_FRAME -> {
                saveNextFrame = true
                return START_STICKY
            }
        }

        createChannel()
        startForeground(7, NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("מאמן פוקר פעיל")
            .setContentText("זיהוי לימודי מסרטון במסך")
            .setOngoing(true)
            .build())

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val data = intent?.getParcelableExtra<Intent>(EXTRA_DATA)
        if (resultCode != 0 && data != null && projection == null) startProjection(resultCode, data)
        return START_STICKY
    }

    private fun startProjection(resultCode: Int, data: Intent) {
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(resultCode, data)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, handler)
        }
        val metrics = resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        imageReader?.setOnImageAvailableListener({ reader ->
            val now = System.currentTimeMillis()
            val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                if (now - lastAnalyzeAt < 850) return@setOnImageAvailableListener
                lastAnalyzeAt = now
                val plane = image.planes[0]
                val buffer = plane.buffer
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                val rowPadding = rowStride - pixelStride * width
                val bitmap = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888)
                bitmap.copyPixelsFromBuffer(buffer)
                val cropped = Bitmap.createBitmap(bitmap, 0, 0, width, height)

                var savedPath = ""
                if (saveNextFrame) {
                    savedPath = saveDebugFrame(cropped)
                    saveNextFrame = false
                }

                val result = detector.detect(cropped, forcedProfile)
                sendBroadcast(Intent(ACTION_DETECTION).apply {
                    putExtra(EXTRA_HERO, result.heroCards.joinToString(",") { it.card.toString() })
                    putExtra(EXTRA_BOARD, result.boardCards.joinToString(",") { it.card.toString() })
                    putExtra(EXTRA_HERO_CONF, result.heroConfidenceText)
                    putExtra(EXTRA_BOARD_CONF, result.boardConfidenceText)
                    putExtra(EXTRA_HERO_MIN_CONF, result.heroCards.minOfOrNull { it.confidence } ?: 0f)
                    putExtra(EXTRA_BOARD_MIN_CONF, result.boardCards.minOfOrNull { it.confidence } ?: 0f)
                    putExtra(EXTRA_DEBUG, result.debugText)
                    putExtra(EXTRA_SAVED_PATH, savedPath)
                })
                bitmap.recycle()
                cropped.recycle()
            } finally {
                image.close()
            }
        }, handler)

        virtualDisplay = projection?.createVirtualDisplay(
            "PokerTrainerCapture",
            width,
            height,
            density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            handler
        )
    }

    private fun saveDebugFrame(frame: Bitmap): String {
        return runCatching {
            val dir = File(getExternalFilesDir(null), "debug_frames")
            dir.mkdirs()
            val file = File(dir, "poker_frame_${System.currentTimeMillis()}.png")
            FileOutputStream(file).use { out -> frame.compress(Bitmap.CompressFormat.PNG, 100, out) }
            file.absolutePath
        }.getOrElse { "שגיאה בשמירה" }
    }

    override fun onDestroy() {
        virtualDisplay?.release()
        imageReader?.close()
        projection?.stop()
        super.onDestroy()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Poker Trainer", NotificationManager.IMPORTANCE_LOW))
        }
    }

    companion object {
        const val ACTION_DETECTION = "com.tomer.pokertrainer.ACTION_DETECTION"
        const val ACTION_STATUS = "com.tomer.pokertrainer.ACTION_STATUS"
        const val ACTION_STOP = "com.tomer.pokertrainer.ACTION_STOP_CAPTURE"
        const val ACTION_SET_PROFILE = "com.tomer.pokertrainer.ACTION_SET_PROFILE"
        const val ACTION_SAVE_NEXT_FRAME = "com.tomer.pokertrainer.ACTION_SAVE_NEXT_FRAME"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_DATA = "data"
        const val EXTRA_HERO = "hero"
        const val EXTRA_BOARD = "board"
        const val EXTRA_HERO_CONF = "heroConf"
        const val EXTRA_BOARD_CONF = "boardConf"
        const val EXTRA_HERO_MIN_CONF = "heroMinConf"
        const val EXTRA_BOARD_MIN_CONF = "boardMinConf"
        const val EXTRA_STATUS = "status"
        const val EXTRA_DEBUG = "debug"
        const val EXTRA_PROFILE = "profile"
        const val EXTRA_SAVED_PATH = "savedPath"
        private const val CHANNEL_ID = "poker_trainer_capture"
    }
}
