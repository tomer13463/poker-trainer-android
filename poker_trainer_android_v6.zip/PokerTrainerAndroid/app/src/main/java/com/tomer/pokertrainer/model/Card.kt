package com.tomer.pokertrainer.model

enum class Rank(val label: String, val value: Int) {
    TWO("2", 2), THREE("3", 3), FOUR("4", 4), FIVE("5", 5), SIX("6", 6), SEVEN("7", 7),
    EIGHT("8", 8), NINE("9", 9), TEN("10", 10), JACK("J", 11), QUEEN("Q", 12), KING("K", 13), ACE("A", 14);

    companion object { val allDesc = entries.sortedByDescending { it.value } }
}

enum class Suit(val symbol: String) {
    SPADES("♠"), HEARTS("♥"), DIAMONDS("♦"), CLUBS("♣")
}

data class Card(val rank: Rank, val suit: Suit) {
    override fun toString(): String = rank.label + suit.symbol
}
