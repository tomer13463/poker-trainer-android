package com.tomer.pokertrainer.poker

data class HandResult(
    val category: String,
    val strengthScore: Int,
    val winChancePercent: Int,
    val improveNextCardPercent: Int,
    val improveToRiverPercent: Int,
    val outs: Int,
    val draws: List<String>,
    val actionLabel: String,
    val explanation: String
)
