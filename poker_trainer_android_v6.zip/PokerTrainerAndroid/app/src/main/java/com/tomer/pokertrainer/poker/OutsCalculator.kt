package com.tomer.pokertrainer.poker

import com.tomer.pokertrainer.model.Card
import com.tomer.pokertrainer.model.Rank
import com.tomer.pokertrainer.model.Suit

class OutsCalculator {
    fun drawsAndOuts(hero: List<Card>, board: List<Card>): Pair<List<String>, Int> {
        val cards = hero + board
        val draws = mutableListOf<String>()
        var outs = 0
        val suitCounts = cards.groupingBy { it.suit }.eachCount()
        if (suitCounts.values.any { it == 4 }) { draws.add("Flush Draw"); outs += 9 }
        if (suitCounts.values.any { it == 3 } && board.size < 5) { draws.add("Backdoor Flush") }
        val ranks = cards.map { it.rank.value }.toMutableSet()
        if (Rank.ACE.value in ranks) ranks.add(1)
        val straightWindows = (5..14).map { high -> (0..4).map { high - it }.toSet() }
        val openStraight = straightWindows.any { w -> w.count { it in ranks } == 4 }
        if (openStraight) { draws.add("Straight Draw"); outs += 8 }
        val pairCount = cards.groupingBy { it.rank }.eachCount().values.count { it >= 2 }
        if (pairCount == 0 && board.size == 0) draws.add("Preflop potential")
        return draws.distinct() to outs.coerceAtMost(20)
    }
}
