package com.tomer.pokertrainer.poker

import com.tomer.pokertrainer.model.Card

class PokerAnalyzer {
    private val evaluator = PokerHandEvaluator()
    private val simulator = MonteCarloSimulator(evaluator)
    private val outsCalculator = OutsCalculator()
    private val improvementCalculator = ImprovementCalculator(evaluator)
    private val explanation = TrainingExplanationEngine()

    fun analyze(hero: List<Card>, board: List<Card>, opponents: Int): HandResult {
        val eval = evaluator.evaluate(hero + board)
        val win = if (hero.size == 2) simulator.estimateWinPercent(hero, board, opponents) else 0
        val improveNext = improvementCalculator.nextCardImprovePercent(hero, board)
        val improveRiver = improvementCalculator.toRiverImprovePercent(hero, board)
        val (draws, outs) = outsCalculator.drawsAndOuts(hero, board)
        val score = when {
            eval.second.contains("Royal") -> 100
            eval.second.contains("Straight Flush") -> 98
            eval.second.contains("Four") -> 94
            eval.second.contains("Full House") -> 88
            eval.second.contains("Flush") -> 78
            eval.second.contains("Straight") -> 70
            eval.second.contains("Three") -> 62
            eval.second.contains("Two Pair") -> 54
            eval.second.contains("One Pair") -> if (isPocketPair(hero)) 70 else 38
            else -> preflopPotential(hero).coerceAtLeast(10)
        }.coerceIn(0, 100)
        val smartScore = when (board.size) {
            0 -> maxOf(score, win)
            else -> ((score * 0.45) + (win * 0.55)).toInt().coerceIn(0, 100)
        }
        val (action, text) = explanation.build(eval.second, win, improveNext, improveRiver, outs, draws, hero, board)
        return HandResult(eval.second, smartScore, win, improveNext, improveRiver, outs, draws, action, text)
    }

    private fun isPocketPair(hero: List<Card>): Boolean = hero.size == 2 && hero[0].rank == hero[1].rank

    private fun preflopPotential(hero: List<Card>): Int {
        if (hero.size != 2) return 0
        val a = hero[0]; val b = hero[1]
        if (a.rank == b.rank) return when (a.rank.value) {
            14 -> 95; 13 -> 90; 12 -> 86; 11 -> 80; else -> 55 + a.rank.value
        }
        val suited = a.suit == b.suit
        val high = maxOf(a.rank.value, b.rank.value)
        val low = minOf(a.rank.value, b.rank.value)
        val gap = kotlin.math.abs(a.rank.value - b.rank.value)
        var score = high * 4 + low * 2
        if (suited) score += 8
        if (gap <= 1) score += 7
        if (gap == 2) score += 3
        if (high == 14 && low >= 10) score += 8
        return score.coerceIn(5, 90)
    }
}
