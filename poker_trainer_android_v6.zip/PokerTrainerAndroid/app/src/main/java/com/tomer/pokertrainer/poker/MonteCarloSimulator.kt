package com.tomer.pokertrainer.poker

import com.tomer.pokertrainer.model.Card
import com.tomer.pokertrainer.model.Rank
import com.tomer.pokertrainer.model.Suit
import kotlin.random.Random

class MonteCarloSimulator(private val evaluator: PokerHandEvaluator = PokerHandEvaluator()) {
    private val fullDeck = Rank.entries.flatMap { r -> Suit.entries.map { s -> Card(r, s) } }

    fun estimateWinPercent(hero: List<Card>, board: List<Card>, opponents: Int, runs: Int = 1200): Int {
        if (hero.size != 2) return 0
        val used = (hero + board).toSet()
        var wins = 0.0
        repeat(runs) {
            val deck = fullDeck.filterNot { it in used }.shuffled(Random.Default).toMutableList()
            val oppHands = (0 until opponents.coerceIn(1, 8)).map {
                listOf(deck.removeAt(0), deck.removeAt(0))
            }
            val completedBoard = board.toMutableList()
            while (completedBoard.size < 5) completedBoard.add(deck.removeAt(0))
            val heroScore = evaluator.evaluate(hero + completedBoard).first
            val oppScores = oppHands.map { evaluator.evaluate(it + completedBoard).first }
            val bestOpp = oppScores.maxOrNull() ?: 0
            if (heroScore > bestOpp) wins += 1.0
            else if (heroScore == bestOpp) wins += 0.5
        }
        return ((wins / runs) * 100).toInt().coerceIn(0, 100)
    }
}
