package com.tomer.pokertrainer.overlay

import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.*
import com.tomer.pokertrainer.model.Card
import com.tomer.pokertrainer.model.Rank
import com.tomer.pokertrainer.model.Suit
import com.tomer.pokertrainer.capture.ScreenCaptureService
import com.tomer.pokertrainer.poker.PokerAnalyzer

class FloatingOverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private val analyzer = PokerAnalyzer()
    private val hero = mutableListOf<Card>()
    private val board = mutableListOf<Card>()
    private var opponents = 2
    private var heroLocked = false
    private var profileMode = "auto"
    private lateinit var resultText: TextView
    private lateinit var winTitle: TextView
    private lateinit var winBar: ProgressBar
    private lateinit var strengthTitle: TextView
    private lateinit var strengthBar: ProgressBar
    private lateinit var futureTitle: TextView
    private lateinit var nextBar: ProgressBar
    private lateinit var riverBar: ProgressBar
    private lateinit var autoText: TextView
    private lateinit var lockBtn: Button
    private lateinit var profileBtn: Button
    private var startX = 0; private var startY = 0; private var touchX = 0f; private var touchY = 0f

    private val detectionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == ScreenCaptureService.ACTION_STATUS) {
                autoText.text = "אוטומטי: ${intent.getStringExtra(ScreenCaptureService.EXTRA_STATUS).orEmpty()}"
                return
            }
            if (intent?.action != ScreenCaptureService.ACTION_DETECTION) return
            val detectedHero = parseCards(intent.getStringExtra(ScreenCaptureService.EXTRA_HERO).orEmpty())
            val detectedBoardRaw = parseCards(intent.getStringExtra(ScreenCaptureService.EXTRA_BOARD).orEmpty())
            val heroConf = intent.getStringExtra(ScreenCaptureService.EXTRA_HERO_CONF).orEmpty()
            val boardConf = intent.getStringExtra(ScreenCaptureService.EXTRA_BOARD_CONF).orEmpty()
            val heroMinConf = intent.getFloatExtra(ScreenCaptureService.EXTRA_HERO_MIN_CONF, 0f)
            val boardMinConf = intent.getFloatExtra(ScreenCaptureService.EXTRA_BOARD_MIN_CONF, 0f)
            val debug = intent.getStringExtra(ScreenCaptureService.EXTRA_DEBUG).orEmpty()
            val savedPath = intent.getStringExtra(ScreenCaptureService.EXTRA_SAVED_PATH).orEmpty()

            // אם הזיהוי לא בטוח, לא מחליפים קלפים קיימים.
            // וגם מונעים מצב של אותו קלף פעמיים ביד.
            if (!heroLocked && detectedHero.size >= 2 && heroMinConf >= 0.58f && detectedHero.distinct().size == detectedHero.size) {
                hero.clear(); hero.addAll(detectedHero.take(2))
                board.removeAll { it in hero }
            }

            val detectedBoard = detectedBoardRaw.filterNot { it in hero }.distinct().take(5)
            // מעדכן לוח רק אם יש זיהוי חדש בטוח עם יותר/שווה קלפים, כדי לא למחוק פלופ בגלל פריים מטושטש.
            if (detectedBoard.isNotEmpty() && detectedBoard.size >= board.size && boardMinConf >= 0.50f) {
                board.clear(); board.addAll(detectedBoard)
            }

            autoText.text = buildString {
                append("אוטומטי: $debug")
                if (heroConf.isNotBlank()) append("\nשלי ביטחון: $heroConf")
                if (boardConf.isNotBlank()) append("\nשולחן ביטחון: $boardConf")
                if (heroMinConf in 0.01f..0.57f) append("\nלא החלפתי יד - ביטחון נמוך")
                if (boardMinConf in 0.01f..0.49f) append("\nלא החלפתי שולחן - ביטחון נמוך")
                if (savedPath.isNotBlank()) append("\nנשמר פריים: $savedPath")
            }
            updateResult()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        root = buildView()
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 35; y = 110 }
        root.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { startX = params.x; startY = params.y; touchX = e.rawX; touchY = e.rawY; true }
                MotionEvent.ACTION_MOVE -> { params.x = startX + (e.rawX - touchX).toInt(); params.y = startY + (e.rawY - touchY).toInt(); wm.updateViewLayout(root, params); true }
                else -> false
            }
        }
        wm.addView(root, params)
        val filter = IntentFilter(ScreenCaptureService.ACTION_DETECTION).apply { addAction(ScreenCaptureService.ACTION_STATUS) }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(detectionReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(detectionReceiver, filter)
        }
    }

    private fun buildView(): LinearLayout {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 18)
            background = GradientDrawable().apply {
                cornerRadius = 28f
                setColor(0xEE111111.toInt())
                setStroke(2, 0xFF00B8FF.toInt())
            }
        }
        val title = TextView(this).apply { text = "מאמן פוקר"; textSize = 18f; setTextColor(0xFFFFFFFF.toInt()); gravity = Gravity.CENTER }
        autoText = TextView(this).apply { text = "אוטומטי: כבוי/ממתין"; textSize = 11f; setTextColor(0xFF7CFF9B.toInt()) }
        resultText = TextView(this).apply { text = "בחר 2 קלפים שלך"; textSize = 14f; setTextColor(0xFFFFFFFF.toInt()) }

        winTitle = barTitle("סיכוי זכייה עכשיו: 0%")
        winBar = bar()
        strengthTitle = barTitle("חוזק יד: 0/100")
        strengthBar = bar()
        futureTitle = barTitle("עתידי: קלף הבא 0% | עד הריבר 0%")
        nextBar = bar()
        riverBar = bar()

        val heroBtn = Button(this).apply { text = "הוסף/תקן קלף שלי"; setOnClickListener { showCardPicker(true) } }
        val boardBtn = Button(this).apply { text = "הוסף/תקן קלף שולחן"; setOnClickListener { showCardPicker(false) } }
        lockBtn = Button(this).apply { text = "נעל יד שלי: כבוי"; setOnClickListener { heroLocked = !heroLocked; text = if (heroLocked) "נעל יד שלי: פעיל" else "נעל יד שלי: כבוי" } }
        profileBtn = Button(this).apply { text = "מסך: אוטומטי"; setOnClickListener { cycleProfile() } }
        val saveFrameBtn = Button(this).apply { text = "שמור פריים דיבאג"; setOnClickListener { sendCaptureAction(ScreenCaptureService.ACTION_SAVE_NEXT_FRAME); autoText.text = "אוטומטי: הפריים הבא יישמר" } }
        val clearBtn = Button(this).apply { text = "איפוס יד"; setOnClickListener { heroLocked = false; hero.clear(); board.clear(); lockBtn.text = "נעל יד שלי: כבוי"; autoText.text = "אוטומטי: אופס, מחכה ליד חדשה"; updateResult() } }
        val stopAutoBtn = Button(this).apply { text = "עצור זיהוי"; setOnClickListener { sendCaptureAction(ScreenCaptureService.ACTION_STOP); autoText.text = "אוטומטי: נעצר" } }
        val close = Button(this).apply { text = "סגור"; setOnClickListener { stopSelf() } }

        val oppRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val oppLabel = TextView(this).apply { text = "שחקנים: $opponents"; setTextColor(0xFFFFFFFF.toInt()); textSize = 14f }
        val minus = Button(this).apply { text = "-"; setOnClickListener { opponents = (opponents - 1).coerceAtLeast(1); oppLabel.text = "שחקנים: $opponents"; updateResult() } }
        val plus = Button(this).apply { text = "+"; setOnClickListener { opponents = (opponents + 1).coerceAtMost(8); oppLabel.text = "שחקנים: $opponents"; updateResult() } }
        oppRow.addView(minus); oppRow.addView(oppLabel); oppRow.addView(plus)

        layout.addView(title)
        layout.addView(autoText)
        layout.addView(resultText)
        layout.addView(winTitle); layout.addView(winBar)
        layout.addView(strengthTitle); layout.addView(strengthBar)
        layout.addView(futureTitle); layout.addView(nextBar); layout.addView(riverBar)
        layout.addView(heroBtn); layout.addView(boardBtn); layout.addView(lockBtn); layout.addView(profileBtn)
        layout.addView(oppRow); layout.addView(saveFrameBtn); layout.addView(clearBtn); layout.addView(stopAutoBtn); layout.addView(close)
        return layout
    }

    private fun cycleProfile() {
        profileMode = when (profileMode) {
            "auto" -> "green_table"
            "green_table" -> "pokerface_red_table"
            else -> "auto"
        }
        profileBtn.text = when (profileMode) {
            "green_table" -> "מסך: שולחן ירוק"
            "pokerface_red_table" -> "מסך: PokerFace אדום"
            else -> "מסך: אוטומטי"
        }
        sendCaptureAction(ScreenCaptureService.ACTION_SET_PROFILE, profileMode)
    }

    private fun sendCaptureAction(action: String, profile: String? = null) {
        startService(Intent(this, ScreenCaptureService::class.java).apply {
            this.action = action
            if (profile != null) putExtra(ScreenCaptureService.EXTRA_PROFILE, profile)
        })
    }

    private fun barTitle(textValue: String): TextView = TextView(this).apply {
        text = textValue
        textSize = 13f
        setTextColor(0xFFFFFFFF.toInt())
        setPadding(0, 8, 0, 2)
    }

    private fun bar(): ProgressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
        max = 100
        progress = 0
        layoutParams = LinearLayout.LayoutParams(520, 28)
    }

    private fun showCardPicker(isHero: Boolean) {
        val popup = PopupWindow(this)
        val wrapper = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFFFFFFFF.toInt()) }
        val hint = TextView(this).apply {
            text = if (isHero) "בחר קלף שלי: לחיצה מחליפה/מוסיפה" else "בחר קלף שולחן: לחיצה מחליפה/מוסיפה"
            setTextColor(0xFF111111.toInt()); textSize = 14f; setPadding(10, 8, 10, 8)
        }
        val grid = GridLayout(this).apply { columnCount = 4; setPadding(8,8,8,8) }
        Rank.allDesc.forEach { r ->
            Suit.entries.forEach { s ->
                val c = Card(r, s)
                val b = Button(this).apply {
                    text = c.toString()
                    textSize = 13f
                    setTextColor(if (s == Suit.HEARTS || s == Suit.DIAMONDS) 0xFFB00020.toInt() else 0xFF111111.toInt())
                    setOnClickListener {
                        if ((hero + board).contains(c)) {
                            Toast.makeText(this@FloatingOverlayService, "הקלף כבר קיים ביד הזאת", Toast.LENGTH_SHORT).show()
                            popup.dismiss(); return@setOnClickListener
                        }
                        if (isHero) {
                            if (hero.size >= 2) hero.removeAt(0)
                            hero.add(c)
                            board.removeAll { it in hero }
                        } else {
                            if (board.size >= 5) board.removeAt(0)
                            board.add(c)
                        }
                        popup.dismiss(); updateResult()
                    }
                }
                grid.addView(b)
            }
        }
        wrapper.addView(hint)
        wrapper.addView(ScrollView(this).apply { addView(grid) })
        popup.contentView = wrapper
        popup.width = 650
        popup.height = 900
        popup.isOutsideTouchable = true
        popup.isFocusable = true
        popup.showAtLocation(root, Gravity.CENTER, 0, 0)
    }

    private fun updateResult() {
        if (hero.size < 2) {
            resultText.text = "קלפים שלי: ${hero.joinToString(" ")}\nבחר 2 קלפים שלך"
            winTitle.text = "סיכוי זכייה עכשיו: 0%"; winBar.progress = 0
            strengthTitle.text = "חוזק יד: 0/100"; strengthBar.progress = 0
            futureTitle.text = "עתידי: קלף הבא 0% | עד הריבר 0%"; nextBar.progress = 0; riverBar.progress = 0
            return
        }
        val res = analyzer.analyze(hero, board, opponents)
        val stage = when (board.size) { 0 -> "לפני פלופ"; 3 -> "פלופ"; 4 -> "טרן"; 5 -> "ריבר"; else -> "שולחן ${board.size}" }
        resultText.text = "שלי: ${hero.joinToString(" ")} ${if (heroLocked) "🔒" else ""}\nשולחן: ${if (board.isEmpty()) "-" else board.joinToString(" ")}\nשלב: $stage | יד: ${res.category}\n${res.actionLabel}\n${res.explanation}"
        winTitle.text = "סיכוי זכייה עכשיו: ${res.winChancePercent}%"
        winBar.progress = res.winChancePercent
        strengthTitle.text = "חוזק יד: ${res.strengthScore}/100"
        strengthBar.progress = res.strengthScore
        futureTitle.text = "עתידי: קלף הבא ${res.improveNextCardPercent}% | עד הריבר ${res.improveToRiverPercent}%"
        nextBar.progress = res.improveNextCardPercent
        riverBar.progress = res.improveToRiverPercent
    }

    private fun parseCards(raw: String): List<Card> {
        if (raw.isBlank()) return emptyList()
        return raw.split(",").mapNotNull { token ->
            val t = token.trim()
            if (t.length < 2) return@mapNotNull null
            val suitSymbol = t.last().toString()
            val rankLabel = t.dropLast(1)
            val rank = Rank.entries.firstOrNull { it.label == rankLabel } ?: return@mapNotNull null
            val suit = Suit.entries.firstOrNull { it.symbol == suitSymbol } ?: return@mapNotNull null
            Card(rank, suit)
        }.distinct()
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(detectionReceiver) }
        if (::root.isInitialized) wm.removeView(root)
        super.onDestroy()
    }
}
