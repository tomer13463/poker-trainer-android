package com.tomer.pokertrainer

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.tomer.pokertrainer.capture.ScreenCaptureService
import com.tomer.pokertrainer.overlay.FloatingOverlayService

class MainActivity : AppCompatActivity() {
    private val captureRequestCode = 9101
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(40, 40, 40, 40)
        }
        val title = TextView(this).apply {
            text = "מאמן פוקר - אישי"
            textSize = 24f
            gravity = Gravity.CENTER
        }
        val desc = TextView(this).apply {
            text = "חלון צף + פס סיכוי זכייה. מצב אוטומטי מיועד ללימוד מסרטוני פוקר בלבד."
            textSize = 16f
            gravity = Gravity.CENTER
        }
        statusText = TextView(this).apply {
            text = "לפני ניסיון: אשר חלון צף ואז אשר צילום מסך. אם אין הרשאה — המד לא יעבוד."
            textSize = 14f
            gravity = Gravity.CENTER
        }
        val manualBtn = Button(this).apply {
            text = "פתח חלון ידני"
            setOnClickListener { openOverlayOnly() }
        }
        val autoBtn = Button(this).apply {
            text = "פתח חלון + זיהוי אוטומטי"
            setOnClickListener { startAutoMode() }
        }
        root.addView(title)
        root.addView(desc)
        root.addView(statusText)
        root.addView(manualBtn)
        root.addView(autoBtn)
        setContentView(root)
    }

    private fun ensureOverlayPermission(): Boolean {
        if (!Settings.canDrawOverlays(this)) {
            statusText.text = "חסרה הרשאת חלון צף. תאשר 'Display over other apps' ואז תחזור לאפליקציה."
            Toast.makeText(this, "צריך לאשר הצגה מעל אפליקציות", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return false
        }
        return true
    }

    private fun openOverlayOnly() {
        if (!ensureOverlayPermission()) return
        statusText.text = "חלון צף נפתח. עכשיו אפשר לבחור קלפים ידנית."
        startService(Intent(this, FloatingOverlayService::class.java))
    }

    private fun startAutoMode() {
        if (!ensureOverlayPermission()) return
        statusText.text = "מבקש הרשאת צילום מסך. חייב לאשר כדי שזיהוי אוטומטי יעבוד."
        startService(Intent(this, FloatingOverlayService::class.java))
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mgr.createScreenCaptureIntent(), captureRequestCode)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequestCode && resultCode == Activity.RESULT_OK && data != null) {
            statusText.text = "זיהוי אוטומטי פעיל. פתח סרטון ובדוק את המד."
            val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(ScreenCaptureService.EXTRA_DATA, data)
            }
            startForegroundService(serviceIntent)
        } else if (requestCode == captureRequestCode) {
            statusText.text = "לא אושרה הרשאת צילום מסך, לכן זיהוי אוטומטי לא הופעל. אפשר להשתמש במצב ידני."
            Toast.makeText(this, "צילום מסך לא אושר", Toast.LENGTH_LONG).show()
        }
    }
}
