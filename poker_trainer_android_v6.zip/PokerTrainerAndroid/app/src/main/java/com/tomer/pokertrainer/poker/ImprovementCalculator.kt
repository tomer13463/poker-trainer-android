package com.tomer.pokertrainer.poker

import com.tomer.pokertrainer.model.Card
import com.tomer.pokertrainer.model.Rank
import com.tomer.pokertrainer.model.Suit

class ImprovementCalculator(private val evaluator: PokerHandEvaluator = PokerHandEvaluator()) {
    private val fullDeck = Rank.entries.flatMap { r -> Suit.entries.map { s -> Card(r, s) } }

    fun nextCardImprovePercent(hero: List<Card>, board: List<Card>): Int {
        if (hero.size != 2 || board.size >= 5) return 0
        val used = (hero + board).toSet()
        val deck = fullDeck.filterNot { it in used }
        val current = evaluator.evaluate(hero + board).first
        val improving = deck.count { card -> evaluator.evaluate(hero + board + card).first > current }
        return ((improving.toDouble() / deck.size.toDouble()) * 100).toInt().coerceIn(0, 100)
    }

    fun toRiverImprovePercent(hero: List<Card>, board: List<Card>): Int {
        if (hero.size != 2 || board.size >= 5) return 0
        val used = (hero + board).toSet()
        val deck = fullDeck.filterNot { it in used }
        val current = evaluator.evaluate(hero + board).first
        var total = 0
        var improving = 0
        val needed = 5 - board.size
        if (needed == 1) return nextCardImprovePercent(hero, board)
        for (i in deck.indices) {
            for (j in i + 1 until deck.size) {
                total++
                val finalBoard = board + deck[i] + deck[j]
                if (evaluator.evaluate(hero + finalBoard).first > current) improving++
            }
        }
        if (total == 0) return 0
        return ((improving.toDouble() / total.toDouble()) * 100).toInt().coerceIn(0, 100)
    }
}
